/* ============================================================================
 * OUTRUN OS — SHARED BINARY ABI (outrun_abi.h)
 * ============================================================================
 * This header is the single source of truth for the memory layout shared by:
 *   - the Rust microkernel        (kernel/src/main.rs, #[repr(C)] mirror)
 *   - user-space C drivers        (drivers/camera_driver.c)
 *   - C++ applications            (apps/stream_app.cpp)
 *   - system services in C        (services/gesture_service.c)
 *   - x86_64 assembly fast paths  (arch/x86_64/ring_fastpath.asm)
 *
 * DESIGN: "grant once, then unrestricted"
 * ---------------------------------------
 * The kernel mediates only the SETUP of a hardware mapping (capability mint +
 * grant). After the grant, the application owns a direct memory-mapped view of
 * the device region. There is no per-frame kernel check, no copy, no prompt.
 * Revocation is generation-based: the kernel bumps the holder's generation
 * counter and the mapping goes dead on the holder's next access check — the
 * kernel never needs to interrupt or trust the app.
 * ============================================================================ */
#ifndef OUTRUN_ABI_H
#define OUTRUN_ABI_H

#include <stdint.h>

#ifdef __cplusplus
  #include <atomic>
  #define OUTRUN_ATOMIC_U64 std::atomic<uint64_t>
#else
  #include <stdatomic.h>
  #define OUTRUN_ATOMIC_U64 _Atomic uint64_t
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ---- Geometry ------------------------------------------------------------ */
#define OUTRUN_MAX_CAPS_PER_REGION  8       /* per-mapping generation slots   */
#define OUTRUN_FRAME_SLOTS          4       /* latest-frame broadcast buffer  */
#define OUTRUN_FRAME_BYTES          16384   /* synthetic frame payload        */

/* ---- One frame slot (seqlock-protected) ---------------------------------- */
/* Producer:  seq++ (odd) -> write payload -> seq++ (even)                    */
/* Consumer:  s1 = seq; if odd retry; read; s2 = seq; if s1 != s2 retry       */
typedef struct {
    OUTRUN_ATOMIC_U64 seq;                  /* even = stable, odd = writing   */
    uint64_t          timestamp_ns;
    uint32_t          frame_id;
    uint32_t          payload_len;
    uint8_t           payload[OUTRUN_FRAME_BYTES];
} outrun_frame_slot;

/* ---- The shared device region -------------------------------------------- */
/* Offsets are load-bearing: the assembly fast paths hardcode them.           */
/*   cap_gen[]       @ offset   0   (8 x u64 = 64 bytes)                      */
/*   latest          @ offset  64                                             */
/*   frames_written  @ offset  72                                             */
/*   slots[]         @ offset 128                                             */
typedef struct {
    OUTRUN_ATOMIC_U64 cap_gen[OUTRUN_MAX_CAPS_PER_REGION];
    OUTRUN_ATOMIC_U64 latest;               /* frame COUNT; slot=(latest-1)%N */
    OUTRUN_ATOMIC_U64 frames_written;
    uint8_t           _pad[48];             /* header padded to 128 bytes     */
    outrun_frame_slot slots[OUTRUN_FRAME_SLOTS];
} outrun_camera_region;

/* ---- x86_64 assembly fast paths (arch/x86_64/ring_fastpath.asm) ----------- */
/* Hot-loop primitives kept in hand-written assembly per project charter.     */

/* Returns region->latest with a single MOV — the poll a consumer spins on.   */
uint64_t outrun_fast_latest(const void *region_base);

/* Generation check: 0 = capability live, 1 = revoked by kernel.              */
uint64_t outrun_cap_check(const void *region_base,
                          uint64_t    cap_index,
                          uint64_t    expected_generation);

/* Emits the PAUSE instruction — polite spin-waiting on hyperthreaded cores.  */
void outrun_cpu_relax(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* OUTRUN_ABI_H */
