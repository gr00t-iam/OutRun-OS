// ============================================================================
// OUTRUN OS — SECTION 1: CONTENT-ADDRESSABLE VIRTUAL FILESYSTEM (cas_vfs.rs)
// ============================================================================
// A working CAS VFS. Files are split into fixed blocks; each block is stored
// and indexed strictly by the hash of its own bytes. A file is not a path in
// a directory tree — it is a MANIFEST (an ordered list of block hashes), and
// the file's own address is the hash of that manifest. There are no nested
// directories anywhere in this store; every object is reached by its content
// hash. Deduplication is automatic and happens at block granularity: two
// files that share any 4 KiB-aligned block share the single stored copy.
//
// FNV-1a stands in for a cryptographic hash for this prototype (the interface
// is identical to a BLAKE3/SHA-256 store; only the digest function changes).
//
// Public surface required by spec:
//   write_file(data) -> file_hash          content-addressed insert
//   read_file(file_hash) -> Option<data>   dynamic block resolution
// plus a live internal tracking array (block table with refcounts).
// ============================================================================

use std::collections::HashMap;

const BLOCK_SIZE: usize = 4096;

/// FNV-1a 64-bit. Swap for a cryptographic digest without touching callers.
fn cas_hash(data: &[u8]) -> u64 {
    let mut h: u64 = 0xcbf2_9ce4_8422_2325;
    for &b in data {
        h ^= b as u64;
        h = h.wrapping_mul(0x0000_0100_0000_01b3);
    }
    h
}

/// One physical block: the bytes, plus a refcount so deduplicated blocks are
/// only reclaimed when the last referencing file is deleted.
struct Block {
    data: Vec<u8>,
    refcount: u64,
}

/// A file is purely an ordered list of block hashes + its true length.
struct Manifest {
    size: usize,
    blocks: Vec<u64>,
}

/// The whole store. No directories — two content-addressed tables and stats.
struct ContentStore {
    blocks: HashMap<u64, Block>,     // the internal tracking array (by hash)
    files: HashMap<u64, Manifest>,   // file_hash -> manifest
    logical_bytes: u64,              // bytes callers wrote
    physical_bytes: u64,             // bytes actually stored after dedup
    dedup_hits: u64,
}

impl ContentStore {
    fn new() -> Self {
        ContentStore {
            blocks: HashMap::new(),
            files: HashMap::new(),
            logical_bytes: 0,
            physical_bytes: 0,
            dedup_hits: 0,
        }
    }

    /// Insert one block content-addressed. If its hash already exists we store
    /// nothing and simply bump the refcount — this is the dedup fast path.
    fn put_block(&mut self, chunk: &[u8]) -> u64 {
        let h = cas_hash(chunk);
        match self.blocks.get_mut(&h) {
            Some(b) => {
                b.refcount += 1;
                self.dedup_hits += 1;
            }
            None => {
                self.physical_bytes += chunk.len() as u64;
                self.blocks.insert(h, Block { data: chunk.to_vec(), refcount: 1 });
            }
        }
        h
    }

    /// write_file: chunk -> content-address each block -> build + address the
    /// manifest. Returns the file's content hash. Writing identical data twice
    /// returns the identical hash and stores zero additional bytes.
    fn write_file(&mut self, data: &[u8]) -> u64 {
        let mut blocks = Vec::new();
        for chunk in data.chunks(BLOCK_SIZE) {
            blocks.push(self.put_block(chunk));
        }
        let mut manifest_bytes = Vec::with_capacity(blocks.len() * 8);
        for h in &blocks {
            manifest_bytes.extend_from_slice(&h.to_le_bytes());
        }
        let file_hash = cas_hash(&manifest_bytes);
        self.logical_bytes += data.len() as u64;
        self.files.insert(file_hash, Manifest { size: data.len(), blocks });
        file_hash
    }

    /// read_file: resolve the manifest, then resolve each block by hash and
    /// concatenate. Blocks are pulled dynamically from the shared store.
    fn read_file(&self, file_hash: u64) -> Option<Vec<u8>> {
        let m = self.files.get(&file_hash)?;
        let mut out = Vec::with_capacity(m.size);
        for h in &m.blocks {
            out.extend_from_slice(&self.blocks.get(h)?.data);
        }
        out.truncate(m.size);
        Some(out)
    }

    fn stats(&self) {
        let saved = self.logical_bytes.saturating_sub(self.physical_bytes);
        let ratio = if self.physical_bytes > 0 {
            self.logical_bytes as f64 / self.physical_bytes as f64
        } else { 1.0 };
        println!("  ── store stats ───────────────────────────────────────────");
        println!("     unique blocks stored : {}", self.blocks.len());
        println!("     files indexed        : {}", self.files.len());
        println!("     logical bytes written: {}", self.logical_bytes);
        println!("     physical bytes stored: {}", self.physical_bytes);
        println!("     dedup block hits     : {}", self.dedup_hits);
        println!("     bytes saved by dedup : {}  ({:.2}x compaction)", saved, ratio);
    }
}

fn main() {
    println!("OUTRUN CAS-VFS — content-addressable store, no directories\n");
    let mut store = ContentStore::new();

    // Build two documents that deliberately SHARE a middle section so we can
    // watch block-level deduplication happen for real.
    let shared_body = vec![b'S'; BLOCK_SIZE * 3];       // 12 KiB identical middle
    let mut doc_a = Vec::new();
    doc_a.extend_from_slice(&vec![b'A'; BLOCK_SIZE]);   // unique head A
    doc_a.extend_from_slice(&shared_body);              // shared
    let mut doc_b = Vec::new();
    doc_b.extend_from_slice(&vec![b'B'; BLOCK_SIZE]);   // unique head B
    doc_b.extend_from_slice(&shared_body);              // shared

    let ha = store.write_file(&doc_a);
    println!("  write_file(doc_a  16 KiB) -> content hash {:016x}", ha);
    let hb = store.write_file(&doc_b);
    println!("  write_file(doc_b  16 KiB) -> content hash {:016x}", hb);
    println!("     (doc_a and doc_b share a 12 KiB body — 3 blocks deduplicated)\n");

    // Content addressing: writing byte-identical data yields the SAME hash and
    // stores nothing new. This is dedup at the whole-file level, for free.
    let ha_again = store.write_file(&doc_a);
    println!("  write_file(doc_a again)   -> content hash {:016x}  {}",
             ha_again, if ha_again == ha { "== identical, 0 new bytes stored" } else { "?!" });
    assert_eq!(ha, ha_again);

    // Round-trip integrity: read each file back by its hash and verify bytes.
    let back_a = store.read_file(ha).expect("doc_a resolvable");
    let back_b = store.read_file(hb).expect("doc_b resolvable");
    println!("\n  read_file({:016x}) -> {} bytes, integrity {}",
             ha, back_a.len(), if back_a == doc_a { "OK" } else { "CORRUPT" });
    println!("  read_file({:016x}) -> {} bytes, integrity {}",
             hb, back_b.len(), if back_b == doc_b { "OK" } else { "CORRUPT" });
    assert_eq!(back_a, doc_a);
    assert_eq!(back_b, doc_b);

    // Unknown hash resolves to None rather than a crash or a wrong file.
    println!("  read_file(0xdeadbeef)     -> {}",
             match store.read_file(0xdead_beef) { Some(_) => "unexpected", None => "None (no such object)" });

    println!();
    store.stats();
    // headA + headB + the shared body (which is itself uniform, so all its
    // 4 KiB chunks dedup to ONE stored block) = 3 unique blocks total.
    assert_eq!(store.blocks.len(), 3);
    println!("\n  ✓ block-level dedup, stable content addressing, and dynamic");
    println!("    block resolution all verified.");
}
