// ============================================================================
// OUTRUN OS — SECTION 3: ASYNCHRONOUS ZERO-COPY PACKET ROUTER (packet_router.cpp)
// ============================================================================
// A lock-free SPSC ring buffer that routes raw network frames to isolated
// per-application workspaces WITHOUT copying the payload. The trick: the ring
// carries fixed-size DESCRIPTORS (offset+len into a shared packet arena plus a
// routing key), never the bytes. enqueue_packet writes each frame into the
// arena exactly once; dequeue_and_route hands the destination app a pointer
// straight into that arena. The payload is touched once on ingress and never
// copied again on its way to the app — true zero-copy delivery.
//
// The head/tail loads on the hot path go through an x86_64 inline-assembly
// primitive (an aligned atomic MOV) to satisfy the polyglot low-level layer,
// with a portable std::atomic fallback for non-x86 builds.
// ============================================================================

#include <atomic>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <array>

// ---- Low-level atomic index load (Assembly on x86_64) ----------------------
static inline uint64_t atomic_load_idx(const std::atomic<uint64_t> &slot) {
#if defined(__x86_64__)
    uint64_t v;
    // Aligned 8-byte load is single-copy atomic on x86_64. Hand-emitting the
    // MOV keeps this off the compiler's fence path — the ring's hot loop.
    __asm__ __volatile__("movq %1, %0"
                         : "=r"(v)
                         : "m"(*reinterpret_cast<const volatile uint64_t *>(&slot)));
    return v;
#else
    return slot.load(std::memory_order_acquire);
#endif
}

// ---- Shared packet arena ----------------------------------------------------
// One big region the NIC DMAs into. Descriptors point in here; nothing that
// leaves ingress ever memcpy's a payload again.
static constexpr size_t ARENA_BYTES = 1u << 20; // 1 MiB
struct PacketArena {
    uint8_t bytes[ARENA_BYTES];
    std::atomic<uint64_t> write_off{0}; // bump allocator (demo-simple)
};

// ---- Ring descriptor: 32 bytes, no payload ---------------------------------
struct PacketDescriptor {
    uint32_t arena_offset; // where the frame lives in the arena
    uint32_t length;       // frame length in bytes
    uint32_t dst_app;      // routing key -> which isolated workspace
    uint32_t src_ip;       // simplified 5-tuple stand-in
};

// ---- Lock-free SPSC ring ----------------------------------------------------
template <size_t CAP>
struct RingBuffer {
    static_assert((CAP & (CAP - 1)) == 0, "CAP must be a power of two");
    alignas(64) std::atomic<uint64_t> head{0}; // consumer cursor
    alignas(64) std::atomic<uint64_t> tail{0}; // producer cursor
    std::array<PacketDescriptor, CAP> slots{};

    bool enqueue(const PacketDescriptor &d) {
        uint64_t t = tail.load(std::memory_order_relaxed);
        uint64_t h = atomic_load_idx(head);
        if (t - h >= CAP) return false;         // ring full, drop
        slots[t & (CAP - 1)] = d;
        tail.store(t + 1, std::memory_order_release);
        return true;
    }

    bool dequeue(PacketDescriptor &out) {
        uint64_t h = head.load(std::memory_order_relaxed);
        uint64_t t = atomic_load_idx(tail);
        if (h == t) return false;               // empty
        out = slots[h & (CAP - 1)];
        head.store(h + 1, std::memory_order_release);
        return true;
    }
};

// ---- Isolated per-app workspace --------------------------------------------
// Each app sees only descriptors routed to it; delivery is a pointer into the
// shared arena, so the app reads the frame in place (zero-copy).
struct AppWorkspace {
    uint32_t app_id;
    uint64_t frames_received = 0;
    uint64_t bytes_seen = 0;
    const uint8_t *last_frame = nullptr; // proves in-place delivery

    void deliver(const uint8_t *frame_ptr, uint32_t len) {
        frames_received++;
        bytes_seen += len;
        last_frame = frame_ptr;             // pointer INTO the arena, not a copy
    }
};

// ---- The router -------------------------------------------------------------
struct Router {
    PacketArena *arena;
    RingBuffer<1024> ring;
    AppWorkspace *apps;
    size_t n_apps;
    uint64_t dropped = 0;

    // enqueue_packet: write the frame into the arena ONCE, push a descriptor.
    bool enqueue_packet(const uint8_t *frame, uint32_t len,
                        uint32_t dst_app, uint32_t src_ip) {
        uint64_t off = arena->write_off.fetch_add(len, std::memory_order_relaxed);
        if (off + len > ARENA_BYTES) { dropped++; return false; }
        std::memcpy(&arena->bytes[off], frame, len); // the single ingress copy
        PacketDescriptor d{ (uint32_t)off, len, dst_app, src_ip };
        if (!ring.enqueue(d)) { dropped++; return false; }
        return true;
    }

    // dequeue_and_route: pop a descriptor and hand the destination app a
    // pointer straight into the arena. No payload copy occurs here.
    int dequeue_and_route() {
        PacketDescriptor d;
        int routed = 0;
        while (ring.dequeue(d)) {
            const uint8_t *frame_ptr = &arena->bytes[d.arena_offset]; // zero-copy
            AppWorkspace *target = nullptr;
            for (size_t i = 0; i < n_apps; i++)
                if (apps[i].app_id == d.dst_app) { target = &apps[i]; break; }
            if (target) { target->deliver(frame_ptr, d.length); routed++; }
            else dropped++;
        }
        return routed;
    }
};

int main() {
    std::printf("OUTRUN PACKET ROUTER — zero-copy SPSC ring, isolated workspaces\n\n");

    static PacketArena arena;
    AppWorkspace apps[3] = { {101}, {102}, {103} };
    Router router{ &arena, {}, apps, 3, 0 };

    // Synthesize frames destined for three different isolated app workspaces.
    const uint32_t dests[3] = { 101, 102, 103 };
    uint8_t frame[512];
    uint32_t total = 0, bytes = 0;
    for (int i = 0; i < 300; i++) {
        uint32_t len = 64 + (i * 7) % 400;
        std::memset(frame, (uint8_t)(i & 0xFF), len);
        std::memcpy(frame, "OUTRUNFR", 8);              // frame magic
        uint32_t dst = dests[i % 3];
        if (router.enqueue_packet(frame, len, dst, 0x0A000001 + i)) {
            total++; bytes += len;
        }
    }
    std::printf("  enqueue_packet : injected %u frames (%u bytes) into the ring\n", total, bytes);

    int routed = router.dequeue_and_route();
    std::printf("  dequeue_and_route: delivered %d frames to isolated workspaces\n\n", routed);

    for (int i = 0; i < 3; i++) {
        // Prove zero-copy: the pointer the app holds lies INSIDE the arena.
        const uint8_t *p = apps[i].last_frame;
        bool in_arena = p >= arena.bytes && p < arena.bytes + ARENA_BYTES;
        bool magic_ok = p && std::memcmp(p, "OUTRUNFR", 8) == 0;
        std::printf("  app %u : %llu frames, %llu bytes, last_frame=%p  %s  magic:%s\n",
                    apps[i].app_id,
                    (unsigned long long)apps[i].frames_received,
                    (unsigned long long)apps[i].bytes_seen,
                    (const void *)p,
                    in_arena ? "[ptr INSIDE arena -> zero-copy]" : "[COPIED?!]",
                    magic_ok ? "ok" : "bad");
    }
    std::printf("  dropped: %llu\n", (unsigned long long)router.dropped);
    std::printf("\n  ✓ payloads copied exactly once (ingress); delivery to each\n");
    std::printf("    isolated workspace was by pointer into the shared arena.\n");
    return 0;
}
