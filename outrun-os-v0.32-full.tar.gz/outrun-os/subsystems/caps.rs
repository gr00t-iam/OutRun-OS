// ============================================================================
// OUTRUN OS — SECTION 2: USER-MODE ISOLATION & CAPABILITY DISPATCHER (caps.rs)
// ============================================================================
// A working microkernel-style process model. Each Process owns an isolated
// virtual address space (mocked as a list of mappings with no way to name
// another process's memory) and a Capabilities bitset. Hardware passthrough
// is gated ENTIRELY by that bitset: sys_hardware_passthrough() maps a device's
// MMIO window into the caller's address space iff the caller holds the bit for
// that device, and strictly drops the request otherwise.
//
// This is the enforcement point behind the manifesto's promise: apps get
// direct, unrestricted, zero-copy MMIO to cameras/mics/controllers WITHOUT a
// prompt — but only for devices they were granted at launch. An app that was
// never granted the microphone bit cannot map it, no matter what it does.
// ============================================================================

use std::collections::HashMap;

// ---- Capability bits --------------------------------------------------------
const CAP_HW_PASSTHROUGH: u64 = 1 << 0; // may map ANY granted device at all
const CAP_CAMERA:         u64 = 1 << 1;
const CAP_MICROPHONE:     u64 = 1 << 2;
const CAP_CONTROLLER:     u64 = 1 << 3;
const CAP_NETWORK:        u64 = 1 << 4;
const CAP_FILESYSTEM:     u64 = 1 << 5;

fn cap_names(bits: u64) -> String {
    let table = [
        (CAP_HW_PASSTHROUGH, "HW_PASSTHROUGH"),
        (CAP_CAMERA, "CAMERA"), (CAP_MICROPHONE, "MIC"),
        (CAP_CONTROLLER, "CONTROLLER"), (CAP_NETWORK, "NET"),
        (CAP_FILESYSTEM, "FS"),
    ];
    let mut v = Vec::new();
    for (bit, name) in table {
        if bits & bit != 0 { v.push(name); }
    }
    if v.is_empty() { "(none)".into() } else { v.join("|") }
}

// ---- A device on the hardware bus ------------------------------------------
#[allow(dead_code)] // mmio_base retained for ktrace / audit symmetry
struct Device {
    name: &'static str,
    mmio_base: u64,
    mmio_len: u64,
    required_cap: u64, // bit a process must hold to map this device
}

// ---- Isolated virtual address space (mock) ---------------------------------
struct Mapping {
    vaddr: u64,
    paddr: u64,
    len: u64,
    label: String,
}

struct AddressSpace {
    // Each process gets a private 47-bit-ish base; nothing here can name
    // another process's regions — that is the isolation boundary.
    next_vaddr: u64,
    mappings: Vec<Mapping>,
}

impl AddressSpace {
    fn new(base: u64) -> Self {
        AddressSpace { next_vaddr: base, mappings: Vec::new() }
    }
    fn map(&mut self, paddr: u64, len: u64, label: String) -> u64 {
        let vaddr = self.next_vaddr;
        self.next_vaddr += (len + 0xFFF) & !0xFFF; // page-align the next slot
        self.mappings.push(Mapping { vaddr, paddr, len, label });
        vaddr
    }
}

// ---- Process ----------------------------------------------------------------
#[derive(PartialEq)]
enum State { Ready, Running, Blocked }

struct Process {
    pid: u64,
    name: String,
    caps: u64,
    vas: AddressSpace,
    state: State,
    quantum_us: u64,
    ran_us: u64,
}

// ---- The microkernel --------------------------------------------------------
struct Microkernel {
    procs: Vec<Process>,
    devices: HashMap<u64, Device>, // keyed by mmio_base
    next_pid: u64,
}

impl Microkernel {
    fn new() -> Self {
        Microkernel { procs: Vec::new(), devices: HashMap::new(), next_pid: 1 }
    }

    fn register_device(&mut self, name: &'static str, base: u64, len: u64, cap: u64) {
        self.devices.insert(base, Device { name, mmio_base: base, mmio_len: len, required_cap: cap });
        println!("[kernel] device '{}' registered at MMIO {:#x}..{:#x}, requires {}",
                 name, base, base + len, cap_names(cap));
    }

    fn spawn(&mut self, name: &str, caps: u64) -> u64 {
        let pid = self.next_pid;
        self.next_pid += 1;
        // Private address space base derived from pid — disjoint per process.
        let base = 0x0000_1000_0000_0000 + (pid << 36);
        self.procs.push(Process {
            pid, name: name.into(), caps,
            vas: AddressSpace::new(base),
            state: State::Ready,
            quantum_us: 2000,
            ran_us: 0,
        });
        println!("[kernel] spawned pid {} '{}' — caps {} — private VAS @ {:#x}",
                 pid, name, cap_names(caps), base);
        pid
    }

    fn proc_mut(&mut self, pid: u64) -> Option<&mut Process> {
        self.procs.iter_mut().find(|p| p.pid == pid)
    }

    // ---- THE CAPABILITY-GATED HARDWARE PASSTHROUGH SYSCALL -----------------
    // Returns Ok(vaddr) with a real mapping into the caller's space, or
    // Err(reason) with NOTHING mapped. This is the whole security model in
    // one function: no capability, no mapping, full stop.
    fn sys_hardware_passthrough(&mut self, pid: u64, device_io_address: u64)
        -> Result<u64, String>
    {
        // Resolve device first (immutable borrow), copy out what we need.
        let (dev_name, dev_len, req) = match self.devices.get(&device_io_address) {
            Some(d) => (d.name, d.mmio_len, d.required_cap),
            None => return Err(format!("no device at MMIO {:#x}", device_io_address)),
        };
        let p = match self.proc_mut(pid) {
            Some(p) => p,
            None => return Err(format!("no such process pid {}", pid)),
        };

        // Gate 1: process must be allowed to do passthrough at all.
        if p.caps & CAP_HW_PASSTHROUGH == 0 {
            return Err(format!(
                "DENIED: pid {} '{}' lacks CAP_HW_PASSTHROUGH", pid, p.name));
        }
        // Gate 2: process must hold the specific device capability.
        if p.caps & req == 0 {
            return Err(format!(
                "DENIED: pid {} '{}' holds {} but device '{}' requires {}",
                pid, p.name, cap_names(p.caps), dev_name, cap_names(req)));
        }

        // Granted: map the device MMIO window straight into the process VAS.
        // This is the zero-copy, prompt-free direct access the charter wants.
        let vaddr = p.vas.map(device_io_address, dev_len,
                              format!("MMIO:{}", dev_name));
        println!("[kernel] GRANT  pid {} '{}' -> '{}' MMIO {:#x} mapped at \
                  vaddr {:#x} (direct, zero-copy)", pid, p.name, dev_name,
                  device_io_address, vaddr);
        Ok(vaddr)
    }

    // ---- Minimal round-robin scheduler -------------------------------------
    fn run_round_robin(&mut self, rounds: usize) {
        println!("\n[kernel] scheduler: round-robin, {} processes, {} rounds",
                 self.procs.len(), rounds);
        for r in 0..rounds {
            for i in 0..self.procs.len() {
                let p = &mut self.procs[i];
                if p.state == State::Blocked { continue; }
                p.state = State::Running;
                p.ran_us += p.quantum_us;
                println!("[sched ] round {} : pid {} '{}' ran {}us (total {}us)",
                         r, p.pid, p.name, p.quantum_us, p.ran_us);
                p.state = State::Ready;
            }
        }
    }

    fn dump_vas(&self, pid: u64) {
        if let Some(p) = self.procs.iter().find(|p| p.pid == pid) {
            println!("[kernel] address space of pid {} '{}':", p.pid, p.name);
            if p.vas.mappings.is_empty() {
                println!("           (no device mappings — fully sandboxed)");
            }
            for m in &p.vas.mappings {
                println!("           vaddr {:#x} -> paddr {:#x}  len {:#x}  {}",
                         m.vaddr, m.paddr, m.len, m.label);
            }
        }
    }
}

fn main() {
    println!("OUTRUN MICROKERNEL — capability-gated hardware passthrough\n");
    let mut k = Microkernel::new();

    // Register the multimedia bus devices from the architecture.
    k.register_device("camera0",     0xF000_0000, 0x10_0000, CAP_CAMERA);
    k.register_device("microphone0", 0xF010_0000, 0x01_0000, CAP_MICROPHONE);
    k.register_device("controller0", 0xF020_0000, 0x00_1000, CAP_CONTROLLER);
    println!();

    // Two apps with DIFFERENT capability sets.
    //   stream-app: a trusted A/V tool granted camera + mic passthrough.
    //   sketchy-app: a sideloaded app granted nothing but filesystem.
    let stream  = k.spawn("stream-app",
                          CAP_HW_PASSTHROUGH | CAP_CAMERA | CAP_MICROPHONE);
    let sketchy = k.spawn("sketchy-app", CAP_FILESYSTEM);
    println!();

    println!("── Attempt 1: stream-app maps the camera (holds the bit) ──");
    match k.sys_hardware_passthrough(stream, 0xF000_0000) {
        Ok(va)  => println!("           app now has direct camera at {:#x}\n", va),
        Err(e)  => println!("           {}\n", e),
    }

    println!("── Attempt 2: stream-app maps the microphone (holds the bit) ──");
    let _ = k.sys_hardware_passthrough(stream, 0xF010_0000);
    println!();

    println!("── Attempt 3: sketchy-app tries the SAME camera (no bit) ──");
    match k.sys_hardware_passthrough(sketchy, 0xF000_0000) {
        Ok(va)  => println!("           UNEXPECTED grant at {:#x}\n", va),
        Err(e)  => println!("           {}\n", e),
    }

    println!("── Attempt 4: sketchy-app tries the microphone (no bit) ──");
    match k.sys_hardware_passthrough(sketchy, 0xF010_0000) {
        Ok(va)  => println!("           UNEXPECTED grant at {:#x}\n", va),
        Err(e)  => println!("           {}\n", e),
    }

    // Prove isolation: the two address spaces are disjoint and each app only
    // sees what it was granted.
    k.dump_vas(stream);
    k.dump_vas(sketchy);

    k.run_round_robin(2);

    println!("\n  ✓ capability bitset enforced: stream-app got direct camera+mic");
    println!("    MMIO with zero prompts; sketchy-app was dropped on both. Same");
    println!("    syscall, opposite outcomes, decided purely by the bitset.");
}
