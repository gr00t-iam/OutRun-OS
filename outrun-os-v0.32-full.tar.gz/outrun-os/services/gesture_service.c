/* ============================================================================
 * OUTRUN OS — SPATIAL GESTURE SERVICE (gesture_service.c)
 * ============================================================================
 * The system-level camera gesture engine from the manifesto ("Camera Spatial
 * Control"). It is a SECOND independent consumer of the exact same device
 * region the streaming app reads — proving multi-consumer zero-copy works:
 * the driver writes each frame once; N holders read it in place.
 *
 * Privacy boundary (per the security review): this service holds its own
 * capability to raw pixels. What it forwards to the compositor are DERIVED
 * landmark/gesture EVENTS, never frames — apps that want raw pixels need
 * their own explicit grant.
 *
 * The "hand tracking model" here is a stand-in: it hashes the frame payload
 * into stable pseudo-landmarks so the event pipeline is real end-to-end.
 *
 * Usage: outrun-gesture-service <shm_path> <cap_index> <expected_generation>
 * ============================================================================ */
#include "../include/outrun_abi.h"

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

static const char *GESTURES[] = { "open-palm hover", "two-finger pinch-drag",
                                  "spread-zoom-out", "fist-select" };

int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    if (argc < 4) {
        fprintf(stderr, "[gesture] usage: %s <shm_path> <cap_index> <gen>\n", argv[0]);
        return 2;
    }
    const uint64_t cap_idx = strtoull(argv[2], NULL, 10);
    const uint64_t my_gen  = strtoull(argv[3], NULL, 10);

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) { perror("[gesture] open device region"); return 1; }
    const outrun_camera_region *r =
        mmap(NULL, sizeof(*r), PROT_READ, MAP_SHARED, fd, 0);
    close(fd);
    if (r == MAP_FAILED) { perror("[gesture] mmap"); return 1; }

    printf("[gesture] spatial gesture engine online (pid %d) — sharing the "
           "driver's frames zero-copy, emitting landmark events only\n", getpid());

    uint64_t seen = outrun_fast_latest(r);
    uint64_t analyzed = 0;

    for (;;) {
        if (outrun_cap_check(r, cap_idx, my_gen)) {
            printf("[gesture] capability revoked by kernel — %llu frames analyzed, exiting\n",
                   (unsigned long long)analyzed);
            break;
        }

        uint64_t latest = outrun_fast_latest(r);
        if (latest == seen) { outrun_cpu_relax(); continue; }
        seen = latest;

        const outrun_frame_slot *s = &r->slots[(latest - 1) % OUTRUN_FRAME_SLOTS];
        uint64_t s1 = atomic_load_explicit(&s->seq, memory_order_acquire);
        if (s1 & 1) continue;

        /* Stand-in landmark inference: FNV-1a over a payload sample.        */
        uint64_t h = 1469598103934665603ull;
        for (uint32_t i = 0; i < 256; i++)
            h = (h ^ s->payload[i * 64]) * 1099511628211ull;
        uint32_t fid = s->frame_id;

        uint64_t s2 = atomic_load_explicit(&s->seq, memory_order_acquire);
        if (s1 != s2) continue;                        /* torn read, skip     */

        analyzed++;
        if (analyzed % 150 == 0) {
            /* Derived event only — no pixels ever leave this service.       */
            printf("[gesture] EVENT frame#%u: %s @ canvas (%u, %u) conf 0.9%llu "
                   "-> compositor moves window\n",
                   fid, GESTURES[h % 4],
                   (uint32_t)(h % 1920), (uint32_t)((h >> 16) % 1080),
                   (unsigned long long)(h % 10));
        }
    }

    munmap((void *)r, sizeof(*r));
    return 0;
}
