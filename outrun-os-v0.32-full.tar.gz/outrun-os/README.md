# OUTRUN OS — Core Prototype v0.1

A working, compiling, running prototype of the Outrun OS core: a memory-safe Rust
microkernel supervisor, user-space drivers in C, applications in C++, and hot-path
primitives in hand-written x86_64 assembly — the full polyglot stack from the
project charter, linked into one boot set by a single `make`.

This is not pseudocode. `make run` boots the kernel simulation and demonstrates
live, with real processes and real shared memory, every load-bearing claim in the
manifesto: zero-copy unrestricted hardware streaming after a one-time capability
grant, a user-space camera driver that segfaults and is restarted in milliseconds
while its consumers never lose a mapping, instant signal-free capability
revocation via generation counters, and an A/B atomic update engine that rejects
a corrupted image, rolls back untouched, and then flips roots reboot-free.

## Build and run

Requirements: `gcc`, `g++`, `nasm`, `make`, and a Rust toolchain (`cargo`). No
external crates or libraries are used anywhere.

    make        # builds all four languages into build/
    make run    # boots the kernel demo (about 5 seconds)
    make clean

## Layout

    include/outrun_abi.h            single source of truth for the shared memory ABI
    arch/x86_64/ring_fastpath.asm   hot-path poll, capability check, cpu_relax (NASM)
    kernel/                         Rust microkernel core: capability table, device
                                    regions, process supervisor, A/B update engine
    drivers/camera_driver.c         user-space C driver; produces 200fps frames,
                                    survives injected faults by isolated restart
    apps/stream_app.cpp             C++ app; consumes frames zero-copy via the asm
                                    fast path, exits gracefully on revocation
    services/gesture_service.c      system gesture engine; second zero-copy consumer,
                                    emits derived landmark events, never raw pixels
    docs/                           ARCHITECTURE.md, SECURITY.md, ROADMAP.md, and a
                                    captured demo-run.log from a real boot

## What a real run looks like

From the captured log in `docs/demo-run.log`: the stream app sustained roughly
188 fps of zero-copy frames (11.2 MB consumed with zero per-frame syscalls); the
injected driver SIGSEGV produced a supervisor restart 18 ms later, and the worst
stall any consumer ever observed across the entire crash was 32.4 ms; revocation
of the app's capability took effect on its very next poll with no signal sent.

## Design resolution baked into this code

The charter demands both unrestricted hardware access and real security. This
prototype implements the reconciliation: the kernel mediates only the *setup* of
a hardware mapping (mint and grant a capability, once), then leaves the data path
entirely — after the grant, access is genuinely direct, zero-copy, and
prompt-free. Revocation never requires trusting or interrupting the holder: the
kernel bumps a generation counter and the mapping is dead on the holder's next
access check, which costs one assembly compare. See `docs/SECURITY.md`.
