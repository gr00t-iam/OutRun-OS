/* ============================================================================
 * OUTRUN OS — USER-SPACE CAMERA DRIVER (camera_driver.c)
 * ============================================================================
 * Runs entirely OUTSIDE the kernel as an ordinary supervised process.
 * Produces synthetic "sensor frames" straight into the shared device region
 * using a seqlock — zero copies, zero syscalls on the hot path.
 *
 * Crash isolation demo: on SIGUSR1 the driver dereferences an invalid MMIO
 * address (simulating a firmware/DMA bug) and dies with SIGSEGV. The kernel
 * supervisor restarts it in milliseconds; consumers never lose their mapping.
 *
 * Usage: outrun-camera-driver <shm_path> <cap_index> <expected_generation>
 * ============================================================================ */
#define _GNU_SOURCE
#include "../include/outrun_abi.h"

#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t g_inject_fault = 0;
static volatile sig_atomic_t g_shutdown     = 0;

static void on_sigusr1(int sig) { (void)sig; g_inject_fault = 1; }
static void on_sigterm(int sig) { (void)sig; g_shutdown     = 1; }

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    if (argc < 4) {
        fprintf(stderr, "[driver] usage: %s <shm_path> <cap_index> <gen>\n", argv[0]);
        return 2;
    }
    const char   *shm_path = argv[1];
    const uint64_t cap_idx = strtoull(argv[2], NULL, 10);
    const uint64_t my_gen  = strtoull(argv[3], NULL, 10);

    signal(SIGUSR1, on_sigusr1);
    signal(SIGTERM, on_sigterm);

    /* The kernel already minted our WRITE capability; the grant is this fd. */
    int fd = open(shm_path, O_RDWR);
    if (fd < 0) { perror("[driver] open device region"); return 1; }

    outrun_camera_region *r = mmap(NULL, sizeof(*r),
                                   PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (r == MAP_FAILED) { perror("[driver] mmap device region"); return 1; }

    /* Resume frame numbering across restarts — consumers see continuity.   */
    uint64_t next_frame = atomic_load(&r->latest);
    printf("[driver ] camera driver online (pid %d) — MMIO region mapped, "
           "resuming at frame %llu\n",
           getpid(), (unsigned long long)next_frame);

    uint8_t scratch_line[64];

    while (!g_shutdown) {
        /* Kernel-side revocation is a single generation bump we observe
         * through the assembly fast path — no signal, no syscall needed.   */
        if (outrun_cap_check(r, cap_idx, my_gen)) {
            printf("[driver ] write capability revoked by kernel — unmapping and exiting\n");
            break;
        }

        if (g_inject_fault) {
            printf("[driver ] !! FAULT INJECTED: dereferencing invalid MMIO address 0x0 "
                   "(simulated firmware/DMA bug)\n");
            fflush(stdout);
            *(volatile int *)0 = 42;        /* SIGSEGV — isolated to this process */
        }

        /* ---- Produce one frame via seqlock (zero-copy, zero-syscall) ---- */
        outrun_frame_slot *s = &r->slots[next_frame % OUTRUN_FRAME_SLOTS];

        atomic_fetch_add_explicit(&s->seq, 1, memory_order_acq_rel);   /* odd  */
        s->timestamp_ns = now_ns();
        s->frame_id     = (uint32_t)next_frame;
        s->payload_len  = OUTRUN_FRAME_BYTES;

        /* Synthetic sensor pattern: cheap to generate, verifiable to read. */
        memset(scratch_line, (uint8_t)(next_frame & 0xFF), sizeof scratch_line);
        for (uint32_t off = 0; off < OUTRUN_FRAME_BYTES; off += sizeof scratch_line)
            memcpy(&s->payload[off], scratch_line, sizeof scratch_line);
        s->payload[0] = 0xA5;                       /* frame magic          */

        atomic_fetch_add_explicit(&s->seq, 1, memory_order_release);   /* even */

        next_frame++;
        atomic_store_explicit(&r->latest, next_frame, memory_order_release);
        atomic_fetch_add_explicit(&r->frames_written, 1, memory_order_relaxed);

        /* ~200 fps synthetic sensor clock */
        struct timespec nap = { 0, 5 * 1000 * 1000 };
        nanosleep(&nap, NULL);
    }

    munmap(r, sizeof(*r));
    printf("[driver ] clean shutdown\n");
    return 0;
}
