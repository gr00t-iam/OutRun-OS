// ============================================================================
// OUTRUN OS — STREAMING APPLICATION (stream_app.cpp)
// ============================================================================
// A sandboxed C++ application that was granted a READ capability to the
// camera region at launch. After that single grant it consumes 200fps of
// frames with ZERO kernel involvement: the poll is one assembly MOV, the
// read is a seqlock over shared memory. This is "unrestricted hardware
// access" done safely — the kernel mediated the setup, not the stream.
//
// It also demonstrates generation-based revocation: when the kernel bumps
// our generation slot, the very next outrun_cap_check() returns 1 and the
// app unmaps and exits gracefully. No signal, no crash, no kernel prompt.
//
// Usage: outrun-stream-app <shm_path> <cap_index> <expected_generation>
// ============================================================================
#include "../include/outrun_abi.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

static uint64_t now_ns() {
    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<uint64_t>(ts.tv_sec) * 1000000000ull + ts.tv_nsec;
}

int main(int argc, char **argv) {
    setvbuf(stdout, nullptr, _IOLBF, 0);
    if (argc < 4) {
        std::fprintf(stderr, "[app] usage: %s <shm_path> <cap_index> <gen>\n", argv[0]);
        return 2;
    }
    const char    *shm_path = argv[1];
    const uint64_t cap_idx  = std::strtoull(argv[2], nullptr, 10);
    const uint64_t my_gen   = std::strtoull(argv[3], nullptr, 10);

    int fd = open(shm_path, O_RDONLY);
    if (fd < 0) { std::perror("[app] open device region"); return 1; }

    auto *r = static_cast<const outrun_camera_region *>(
        mmap(nullptr, sizeof(outrun_camera_region), PROT_READ, MAP_SHARED, fd, 0));
    close(fd);
    if (r == MAP_FAILED) { std::perror("[app] mmap device region"); return 1; }

    std::printf("[app    ] stream app online (pid %d) — READ capability granted, "
                "zero-copy mapping live\n", getpid());

    uint64_t seen          = outrun_fast_latest(r);
    uint64_t frames        = 0;
    uint64_t bytes         = 0;
    uint64_t last_frame_ns = now_ns();
    uint64_t max_gap_ns    = 0;      // biggest stall — exposes driver restarts
    const uint64_t t_start = last_frame_ns;

    for (;;) {
        // --- Revocation check: one asm compare, no syscall ----------------
        if (outrun_cap_check(r, cap_idx, my_gen)) {
            const double secs = double(now_ns() - t_start) / 1e9;
            std::printf("[app    ] capability revoked by kernel — unmapping.\n");
            std::printf("[app    ] session stats: %llu frames, %.1f MB consumed zero-copy, "
                        "avg %.0f fps, worst stall %.1f ms (the driver crash)\n",
                        (unsigned long long)frames, double(bytes) / 1e6,
                        frames / secs, double(max_gap_ns) / 1e6);
            break;
        }

        // --- Poll: a single MOV in assembly -------------------------------
        const uint64_t latest = outrun_fast_latest(r);
        if (latest == seen) { outrun_cpu_relax(); continue; }

        // --- Seqlock read of the newest stable frame ----------------------
        const outrun_frame_slot *s = &r->slots[(latest - 1) % OUTRUN_FRAME_SLOTS];
        uint64_t s1 = s->seq.load(std::memory_order_acquire);
        if (s1 & 1) { outrun_cpu_relax(); continue; }            // mid-write

        const uint8_t  magic = s->payload[0];
        const uint32_t fid   = s->frame_id;
        const uint32_t len   = s->payload_len;

        uint64_t s2 = s->seq.load(std::memory_order_acquire);
        if (s1 != s2) continue;                                   // torn, retry

        if (magic != 0xA5) continue;                              // not stamped yet

        const uint64_t t = now_ns();
        const uint64_t gap = t - last_frame_ns;
        if (frames > 0 && gap > max_gap_ns) max_gap_ns = gap;
        last_frame_ns = t;

        seen    = latest;
        frames += 1;
        bytes  += len;

        if (frames % 200 == 0)
            std::printf("[app    ] consumed frame #%u — %llu total, worst stall so far %.1f ms\n",
                        fid, (unsigned long long)frames, double(max_gap_ns) / 1e6);
    }

    munmap(const_cast<outrun_camera_region *>(r), sizeof(outrun_camera_region));
    return 0;
}
