# Outrun OS v0.16 — Phase 5 complete: production hardening + NVMe install image

Adds the production validation matrix and a dd-able, UEFI-bootable disk image that
installs the OS onto a raw NVMe drive.

## ELF loader hardening (strict segment bounds-checking)
- elf_load now takes the image size and validates everything before mapping:
  header fits, program-header table in bounds, entry inside the user range, and
  per-segment checks (file offset+filesz within the image, memsz >= filesz,
  segment <= 16 MiB, vaddr+memsz inside the user range with no overflow).
- Hostile or truncated images are rejected cleanly instead of faulting.

## Capability audit across syscall entry points
- Automated check that every gated syscall enforces its capability: sys_open /
  sys_read / sys_write require CAP_FILESYSTEM, sys_wait_event requires
  CAP_NETWORK, sys_map_framebuffer requires CAP_FRAMEBUFFER — each denied for a
  process lacking the bit and allowed for one holding it.

## Automated integrity suite (`validate` command, runs at boot)
- 19 checks, all passing:
  - 6 capability-audit checks (5 denials + 1 grant),
  - 7 ELF bounds checks (1 valid accepted + 6 hostile images rejected),
  - 6 CAS/VFS integrity checks (byte-exact put/get round-trip, dedup gives same
    hash + no new block, unknown-hash lookup rejected, multi-block VFS
    write/read round-trip, copy-on-write changes the file hash).
- Prints "ALL CHECKS PASSED - image is production-verified".

## dd-able NVMe install image (UEFI)
- New `make install-img` (mkinstall.sh + mkgpt.py) builds build/outrun-install.img:
  a GPT disk with a protective MBR, primary+backup GPT headers, and an EFI System
  Partition (FAT) holding a standalone GRUB EFI (BOOTX64.EFI, GOP framebuffer
  negotiated), the kernel, and the ring-3 ELF.
- Install to a real drive with:   dd if=outrun-install.img of=/dev/nvme0n1 bs=4M
- Verified booting as an emulated NVMe drive under UEFI (OVMF): GRUB multiboot2-
  loads the kernel, the framebuffer comes up (1024x768x32), DHCP completes, the
  validation matrix reports 19/19, the Metropolis-Terminal compositor animates,
  the ring-3 graphics manager maps the framebuffer, and the shell is reached.
  (Screenshot: docs/nvme-boot-compositor.png.)

## Proof
- docs/validation-boot.log — the full 19/19 validation run.
- docs/nvme-boot-compositor.png — the desktop rendered from the NVMe/UEFI boot.

## Status
Phases 2-5 of the blueprint are implemented and verified on bare metal:
preemptive scheduler + concurrent I/O, VFS + exec-from-CAS, async IRQ routing +
zero-copy IP/UDP router, framebuffer + Metropolis-Terminal compositor, the
Time-Stream engine, and now production validation + an installable NVMe image.
