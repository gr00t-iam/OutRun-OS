# Outrun OS v0.22 — IOMMU track: ACPI/DMAR discovery + Intel VT-d DMA remapping

Opens the hypervisor/IOMMU track with the half that actually gates secure device
passthrough: hardware DMA isolation. Devices are now confined to page tables the
kernel controls, and this is proven on real (emulated) VT-d hardware.

## ACPI table discovery
- RSDP captured from Multiboot2 tags 14 (ACPI 1.0) and 15 (ACPI 2.0+), so it
  works under both BIOS/GRUB and UEFI.
- RSDT/XSDT walker with checksum validation; acpi_find_table() locates tables by
  signature (prefers the 64-bit XSDT when present).

## DMAR parsing
- Parses the ACPI DMAR table: host address width, DRHD units (remapping hardware
  register base + segment + INCLUDE_PCI_ALL scope), and RMRR reserved regions.
- Found on QEMU q35: DRHD #1 with registers at phys 0xfed90000.

## Intel VT-d driver (DMA remapping)
- Maps the remapping registers into the kernel device MMIO window and decodes
  VER/CAP/ECAP: domains supported, MGAW, SAGAW, superpage sizes, IR capability.
- Adapts to the hardware: SAGAW is read at runtime and the second-level page
  tables are built 4-level (48-bit AGAW) or 3-level (39-bit) accordingly, using
  2 MiB superpages when CAP.SLLPS reports support. On QEMU this correctly selects
  3-level / 2 MiB / 1024 MiB identity map.
- Builds root table -> per-bus context tables -> second-level page tables, sets
  RTADDR, issues SRTP, performs global context-cache + IOTLB invalidation, then
  sets GCMD.TE and confirms GSTS.TES. Enabled BEFORE PCI enumeration so devices
  come up already under translation.

## virtio driver fix: VIRTIO_F_ACCESS_PLATFORM
Real bug found and fixed: the virtio drivers negotiated only VIRTIO_F_VERSION_1,
so with a vIOMMU present the devices BYPASSED it entirely (virtio only uses the
platform/IOMMU address space when VIRTIO_F_ACCESS_PLATFORM, feature bit 33, is
negotiated). Both virtio-blk and virtio-net now negotiate bit 33 when offered —
their DMA genuinely walks our IOMMU page tables. Backward compatible: when the
device does not offer bit 33 (no IOMMU), behaviour is unchanged.

## `iommu` command — status + LIVE DMA isolation proof (6/6)
- DMA translation enabled (GSTS.TES) and root table programmed (GSTS.RTPS).
- Isolation: the NIC's context entry is pointed at a domain that maps NOTHING,
  then the device is made to attempt a real DMA. The hardware BLOCKS it and
  records the fault, e.g.:
    fault: source-id 18 (0:3.0) addr 0x1017000 reason 6 (read access denied) op=read
  The fault names the offending device (source-id matches the NIC's BDF) — this
  is per-device DMA confinement, the exact property secure passthrough needs.
- The domain is then restored and the device DMAs cleanly again; translation
  stays enabled across the domain churn.
- Fault-recording registers (FRCD at CAP.FRO) are parsed properly: source-id,
  faulting address, reason code, read/write.

## Honest scope
- VT-x/VMX is NOT usable here and this is reported, not faked: there is no KVM in
  this environment and QEMU's TCG interpreter does not emulate VMXON, so a
  hypervisor cannot execute a guest. `[virt] CPUID.1:ECX.VMX = 0`. The IOMMU half
  is fully real and is what gates safe passthrough; guest execution would need a
  host with KVM.
- Interrupt remapping (IR) is not enabled (QEMU reports no-IR in this config);
  DMA remapping only.
- All devices on bus 0 currently share one identity-mapped domain (domain-id 1).
  Per-device restricted domains are demonstrated by the isolation test; wiring
  them to the capability system is the natural next step.

## Verified
- BIOS ISO on q35 + intel-iommu: 19/19 validation, 21/21 invariants, 10/10 stress,
  8/8 fuzz, sweep PASS, 6/6 IOMMU, CAS + DHCP (both DMA through the IOMMU),
  compositor, ring-3, shell. Zero exceptions.
- NVMe/UEFI install image on q35 + intel-iommu: same, ACPI 2.0 RSDP from UEFI.
- REGRESSION: standard i440fx boot with NO IOMMU still fully green — reports
  "no DMAR table" and degrades gracefully.
- New `make qemu-iommu` target.
