# Outrun OS v0.21 — periodic descriptor-table integrity sweep (folded into the scheduler tick)

The page-table auditor is no longer an on-demand scan: it now runs continuously
in the background, driven by the 100 Hz timer tick, so corruption is detected as
it happens rather than only when a test is invoked.

## Design: amortized, bounded, interrupt-safe
The timer tick runs in interrupt context, so a full page-table walk there would
be far too much work. The sweep is INCREMENTAL instead:
- Each tick audits a bounded batch (SWEEP_BATCH = 64 leaf entries) and advances
  a persistent 4-level cursor (PML4 -> PDPT -> PD -> PT), so it resumes exactly
  where it left off — including mid-page-table.
- A full pass over the kernel address space completes across many ticks, then
  the cursor wraps and the next pass begins. Fixed, predictable per-tick cost.
- sweep_tick() takes no locks, allocates nothing, and prints nothing: it only
  reads page tables and updates counters — safe to call from the ISR.

## Invariants checked on every leaf entry
- Reserved bits [52..58] are zero (bit-flip / corruption detection).
- W^X: no page is both writable and executable.
- Kernel .text stays exactly R+X (present, not writable, not NX).

## Armed at boot
Enabled immediately after harden_kernel_wx(), so the invariants it audits are
already established: "descriptor-table integrity sweep armed: 64 entries/tick
@ 100 Hz".

## `sweep` command — status + LIVE detection proof
Reports passes completed, leaf entries audited, and violations found. Then it
proves the auditor is real: it injects a reserved-bit flip into a live PD entry
and waits for the BACKGROUND sweep (not an on-demand scan) to report it.

Measured at boot:
- 5 full passes completed, 5285 leaf entries audited, 0 violations on the
  healthy system.
- Injected flip caught by the background sweep at va 0x200000 after ~6-7 ticks
  (~60-70 ms), then the entry is repaired and the system continues.

## Proof (docs/sweep-boot.log)
Full boot green with the sweep running continuously: 19/19 validation, 21/21
invariants, 10/10 stress, 8/8 fuzz, sweep PASS, DHCP, animated compositor,
ring-3 (guarded stacks + register preservation), shell. No measurable disruption
to the scheduler, networking, or the compositor.

## Honest scope
This audits the KERNEL address space (the shared identity map + kernel tables),
which is where corruption is fatal; per-process user tables are validated by the
on-demand invariants suite. Detection is a software invariant auditor, not ECC:
it catches flips in bits the invariants constrain (reserved, W^X, .text
permissions), not arbitrary data corruption.

## Status
This completes the hardening wishlist: exhaustive capability isolation, W^X/NX
enforcement, guard pages + stack canaries, syscall-argument fuzzing with
user-pointer validation, and now continuous background integrity auditing.
