# Outrun OS v0.5 — what changed

Two things that were previously stubbed are now real: the device behind the
capability syscall, and the origin of the user program.

## 1. A real virtio device behind sys_hardware_passthrough
- New PCI enumeration over configuration mechanism #1 (ports 0xCF8/0xCFC):
  walks bus 0, prints every function's vendor/device/class.
- Finds the virtio device (vendor 0x1AF4), parses its VIRTIO-modern vendor
  capability list to locate the COMMON_CFG and DEVICE_CFG structures, reads and
  sizes the memory BAR that carries them, and enables PCI memory-space decode.
- Registers that REAL physical MMIO window as a capability-gated device
  ('virtio-net', requires CAP_NETWORK). The same sys_hardware_passthrough that
  used to hand out a scratch page now installs PTEs over actual device registers.
- Proof (docs/virtio-elf-boot.log): the authorized ring-3 process maps the BAR
  and reads the virtio-net MAC directly out of the device-config registers. With
  `mac=52:54:00:ab:cd:ef` on the QEMU command line, the unprivileged program
  reads back exactly 52:54:00:ab:cd:ef — through its own page tables. Works with
  the BAR in the 32-bit hole (BIOS, phys 0xFE000000) and as a 64-bit BAR above
  4 GiB (UEFI, phys 0xC000000000). Unauthorized process still gets -2, unmapped.
- If QEMU is booted without a virtio device, the kernel falls back to the scratch
  sentinel so the demo still runs.

## 2. The user program is a real ELF loaded from the ISO
- New freestanding userland program `user/init.c`, linked at the user virtual
  base (0x500000000000) as a standalone ELF64 with no libc and no kernel linkage
  — its only interface is the `syscall` instruction.
- Shipped on the ISO and loaded by GRUB as a Multiboot2 module (`module2` in
  grub.cfg). The kernel reads the module tag, then a real ELF64 loader parses the
  program headers and maps each PT_LOAD segment at its p_vaddr with PTE_USER
  (read-only segments stay read-only), sets up a user stack, and jumps to e_entry.
- Each process runs in its OWN address space now (CR3 switched on entry, restored
  on SYS_EXIT), so a granted MMIO mapping is actually visible to the unprivileged
  code that requested it.
- The embedded blob remains only as a fallback if no module is present on the ISO.

## syscall ABI fix
- `syscall_entry` now preserves the full set of caller-saved argument registers
  (rdi, rsi, rdx, r8, r9, r10) in addition to rcx/r11, matching the syscall ABI
  the C compiler assumes for userspace. (Without this, values held across a
  syscall in userspace were being corrupted.)

## Build / run
- `make` builds the kernel, the user ELF, and the hybrid ISO (now 0.5.0).
- `make qemu` boots headless with `-device virtio-net-pci` attached.
