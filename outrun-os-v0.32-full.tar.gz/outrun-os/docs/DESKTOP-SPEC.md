# Outrun OS — Desktop Environment Engineering & Visual Design Specification

Document version 0.3 · Target: the Outrun OS compositor, shell, and workspace layer
Authoring roles: OS Architecture + Principal UI/UX Engineering

This specification defines concrete design patterns, data structures, interface
dimensions, and layouts for the Outrun OS desktop environment. All dimensions
are given in logical points (pt); the compositor multiplies by the display
scale factor (1.0 at ~110 PPI, 2.0 at ~220 PPI) at shader time, so every value
below is resolution-independent unless a raw pixel value is stated explicitly.

---

## SECTION 1 — Visual Identity & the Spatial Canvas Interface

### 1.1 The visual language: Generative Glass

Outrun's surfaces are not flat fills. Every panel is a **glass layer** composited
in three stacked passes over whatever is behind it. The compositor runs these as
GPU fragment shaders; nothing here is a pre-baked bitmap.

Each glass layer is described by this structure, which the compositor uploads as
a per-surface uniform block:

```c
struct GlassLayer {
    float    blur_sigma;        // Gaussian blur radius, in pt (see table)
    float    saturation;        // backdrop chroma boost, 1.0 = passthrough
    float    tint_rgba[4];      // material tint applied over the blur
    float    noise_amplitude;   // dither to kill banding, ~0.006
    float    depth_z;           // 0.0 = focused, larger = further back
    float    corner_radius_pt;  // 12 window, 8 panel, 6 control
    uint32_t contrast_mode;     // 0 auto, 1 force-dark-text, 2 force-light-text
};
```

The three passes, in order:

1. **Backdrop blur.** A separable Gaussian sampled from the framebuffer region
   directly behind the surface. Blur sigma is quantized by role so the whole UI
   reads as one coherent depth stack rather than a soup of random blurs:

   | Surface role            | blur_sigma (pt) | saturation | tint alpha |
   |-------------------------|-----------------|------------|------------|
   | Global status bar       | 20              | 1.15       | 0.55       |
   | Background window glass  | 32              | 1.05       | 0.42       |
   | Foreground panel / sheet | 16              | 1.20       | 0.60       |
   | Accelerator HUD          | 48              | 1.30       | 0.72       |
   | Context ribbon          | 24              | 1.10       | 0.50       |

   Higher sigma = more separation from content behind it. The HUD blurs hardest
   (48pt) because it must feel like it floats above everything.

2. **Chroma-adaptive tint.** After blur, the shader samples the mean color of
   the blurred backdrop and rotates the material tint toward it by 18–24% so the
   glass "belongs" to the wallpaper without becoming the wallpaper. Saturation is
   boosted per the table so blurred content stays lively rather than muddy.

3. **Contrast guarantee (the important part).** Before any text draws, the shader
   computes the mean relative luminance `L_bg` of the blurred-and-tinted region
   under the text's bounding box using the WCAG luminance formula:

   ```
   L = 0.2126·R_lin + 0.7152·G_lin + 0.0722·B_lin
   ```
   where each channel is linearized (`c ≤ 0.03928 ? c/12.92 : ((c+0.055)/1.055)^2.4`).

   It then picks the text color (near-white `#F2F4F8` or near-black `#0B0E14`)
   that maximizes contrast ratio:

   ```
   CR = (L_lighter + 0.05) / (L_darker + 0.05)
   ```

   If the winning `CR < 4.5` (WCAG AA for body text), the shader deepens the
   glass tint alpha in a local feedback loop, +0.04 per step up to +0.20, until
   `CR ≥ 4.5`. For text ≥ 20pt semibold the threshold relaxes to 3.0 (AA large).
   Headline chrome targets 7.0 (AAA). The result: **readable text over any
   wallpaper, guaranteed by math at composite time**, not by the app developer
   remembering to test on a bright background.

### 1.2 Shadow depth scaling

Windows cast shadows whose softness and offset scale with **interaction
recency**, not a fixed z-index. The compositor keeps a monotonic
`last_focus_tick` per window and derives a depth rank `d` (0 = most recently
focused). Shadow parameters:

```
offset_y_pt = 4 + 6·d          (clamped at d = 4)
blur_pt     = 12 + 10·d
spread_pt   = -2                (tight inner spread keeps edges crisp)
alpha       = 0.38 − 0.05·d     (further windows cast fainter shadows)
```

So the active window sits under a tight, dark, close shadow
(`0, 4pt, 12pt, rgba(0,0,0,0.38)`); a window four layers back casts a soft, wide,
faint one (`0, 28pt, 52pt, rgba(0,0,0,0.18)`). This makes focus **physically
legible** — your eye finds the active window because it is the one floating
lowest and hardest, exactly like a real object closest to a light source.

### 1.3 The Infinite Canvas: windows as physical bodies

Windows are rigid bodies on a 2D canvas with a real physics integrator running
at the compositor's refresh rate (120 Hz where available, 60 Hz floor). Each
window carries:

```c
struct CanvasBody {
    double  x, y;             // canvas-space position (pt), unbounded
    double  vx, vy;           // velocity (pt/s)
    double  w, h;             // extent (pt)
    double  mass;             // = (w·h) / 10000, so big windows feel heavier
    double  k_spring;         // restoring stiffness, default 220 N/m-equivalent
    double  zeta;             // damping ratio, default 0.82 (snappy, minimal overshoot)
    uint8_t pinned;           // 1 = ignores pushes (user-anchored)
};
```

**Motion.** A window being dragged is kinematic (follows the cursor/finger). On
release it integrates under a critically-tuned spring toward its resting slot:

```
c      = 2·zeta·sqrt(k_spring·mass)     // damping coefficient
F      = −k_spring·(pos − target) − c·velocity
accel  = F / mass
```

`zeta = 0.82` is deliberately just under 1.0: windows settle fast with a single
barely-perceptible overshoot, which reads as "alive" without the nauseating
bounce of an underdamped (`zeta < 0.5`) spring.

**Non-overlap by collision, not by tiling.** When a window is dropped onto space
occupied by another, the physics solver treats them as colliding AABBs and
resolves penetration by applying separating impulses along the minimum
translation vector, weighted by mass. A small window shoved at a large one moves
mostly itself; a large window shoved at a small one pushes the small one aside.
Neighbors ripple outward and settle. **Windows never stack into a hidden pile —
they make room.** Pinned windows have infinite effective mass and do not move.

**Infinite zoomable space.** The canvas has no edges. A camera transform
`(cam_x, cam_y, cam_scale)` maps canvas space to the display. Pinch or
Ctrl+scroll drives `cam_scale` across a range of 0.05 (whole-project bird's-eye)
to 2.0 (zoomed into one window). Below `cam_scale = 0.35` windows render as
**glyph cards** — title, app icon, and a 4-line content thumbnail — so a zoomed-
out project landscape stays legible instead of becoming unreadable slivers.

### 1.4 Main desktop wireframe

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ ◐ Outrun   ⌂ Canvas ▸ "App-Core"        ⌕ Search (Alt+Space)        ▣ 78% ⏻ 10:08│  ← Global status bar (32pt)
├──────────────────────────────────────────────────────────────────────────────┤
│  ┌─ Hardware Passthrough ─────────────┐                                        │
│  │ ● camera0   → stream-app  [DIRECT] │   ← live passthrough widget (pinned)   │
│  │ ● mic0      → mixer       [DIRECT] │      shows which app owns which device  │
│  │ ○ pad0      → (unclaimed)          │                                        │
│  └────────────────────────────────────┘                                        │
│                                                                                │
│        ┌───────────────────────────┐              ┌──────────────────────┐     │
│        │  TIME-STREAM              │   (elastic    │  COMM-DECK           │     │
│        │  ◄ Mar 2026 ─── Today ►   │    spacing    │  Sarah · Dev Chat    │     │
│        │  [ img ] [ doc ] [ pdf ]        │    gap ~40pt) │  ✉ 3  ● 1            │     │
│        │  active shadow: tight     │  ◄~~~~~~~~~►  │  glass: background    │     │
│        └───────────────────────────┘              └──────────────────────┘     │
│                                                                                │
│    ┌──────────────────────────────────────────────────────────────────┐       │
│    │  ▶ Active Workspace: Video Editor                                  │       │
│    │    direct 4K camera feed + audio HAL ring · casts tightest shadow  │       │
│    │    (this window is depth rank 0 → floats lowest, darkest shadow)   │       │
│    └──────────────────────────────────────────────────────────────────┘       │
│                                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ Context ▸ scroll: zoom canvas · 3-finger drag: pan · drop window: bodies part  │  ← Context ribbon (28pt)
└──────────────────────────────────────────────────────────────────────────────┘
```

- **Global status bar:** 32pt tall, `blur_sigma 20`, full width. Left: system
  glyph + current canvas breadcrumb. Center: the Accelerator HUD trigger. Right:
  battery/network/clock. It is the only always-pinned chrome.
- **Hardware passthrough widget:** a pinned canvas body, 260×96pt, that names
  every device currently memory-mapped into an app and which app holds it. A
  filled dot (`●`) = live direct passthrough; hollow (`○`) = unclaimed. This is
  the visible face of the capability model — you can always see who is holding
  your camera.
- **Context ribbon:** 28pt tall, `blur_sigma 24`, bottom-anchored, monochrome.
  Its text is rewritten every frame to describe what the current pointer/gesture
  will do in the hovered surface.

---

## SECTION 2 — The Universal Runtime & Application Layout

### 2.1 Dual distribution framework

Every app, regardless of origin, is delivered as an **Outrun Bundle**: a
content-addressed, read-only image plus a capability manifest. Two paths produce
bundles; both feed the identical sandbox.

```
             ┌──────────────────────── OUTRUN BUNDLE ───────────────────────┐
             │  image: CAS root hash (all deps included, read-only)          │
             │  manifest: requested capabilities + UI-compliance attestation │
             │  signature: publisher key (Marketplace CA) OR self-signed key │
             └───────────────────────────────────────────────────────────────┘
                    ▲                                            ▲
        ┌───────────┴───────────┐                    ┌───────────┴───────────┐
        │   OUTRUN MARKETPLACE   │                    │  DECENTRALIZED CHANNEL │
        │  • automated UI check  │                    │  • git:// or ipfs:// URL│
        │  • static bytecode audit│                   │  • self-signed key      │
        │  • 0% tax on free apps │                    │  • local build/interpret│
        │  • 2–5% flat on paid   │                    │  • web-of-trust pinning │
        └────────────────────────┘                    └────────────────────────┘
```

**Marketplace intake pipeline (per submission):**

1. **UI-compliance scan.** A headless compositor renders the app across four
   synthetic displays (1080p@1.0, 1440p@1.5, 4K@2.0, 8K@2.0) in both light and
   dark, and asserts: uses system glass tokens, honors the 8pt grid, text passes
   the §1.1 contrast math, no hardcoded pixel fonts. Failures return a
   screenshot diff, not a rejection letter.
2. **Static bytecode audit.** The WASM/native image is scanned for undeclared
   capability use, embedded telemetry endpoints, and known-malicious code
   patterns. Anything reaching hardware or network that the manifest did not
   declare is flagged.
3. **Publish.** Passing bundles are pinned by content hash. Free apps pay
   nothing, ever; paid apps carry a flat 2–5% processing fee that covers hosting
   only — there is no 30% gate.

**Decentralized path:** `outrun install git://github.com/dev/app` clones,
builds or interprets locally into a bundle, signs it with the developer's key,
and pins the key on first install as a trust anchor. Subsequent updates from a
new key for the same app surface a clear trust-change prompt. No central
gatekeeper is involved, and the sandbox applied is byte-for-byte the same one
Marketplace apps get.

### 2.2 Compatibility: the container/VM layer

Outrun ships a low-overhead runtime matrix so users have software on day one:

| Target                | Mechanism                                   | Isolation boundary          |
|-----------------------|---------------------------------------------|-----------------------------|
| Outrun-native (WASM)  | in-process WASM runtime, capability imports | capability manifest         |
| Outrun-native (ELF)   | direct exec in a sandbox namespace          | capability manifest         |
| Linux binaries        | micro-VM with a paravirtual syscall bridge  | hardware virtualization     |
| Android APKs          | micro-VM running an AOSP userspace + ART    | hardware virtualization     |

The Linux/Android micro-VMs are **not** full emulators; they are thin VMs (a
single kernel, virtio devices, direct-mapped GPU where permitted) that boot in
well under a second and present their apps as ordinary canvas bodies. A Linux
app and a native app sit side by side on the same infinite canvas, each in its
own glass frame.

### 2.3 Unrestricted hardware access, inside the sandbox

This is the reconciliation the project insists on: **direct MMIO to
cameras/mics/controllers with no prompt walls, while still sandboxed.** The
mechanism is grant-at-setup, unrestricted-at-use, exactly as implemented in the
`caps.rs` subsystem prototype accompanying this spec.

Flow when an app requests a device:

```
app calls sys_hardware_passthrough(self, device)
        │
        ▼
microkernel checks the app's Capabilities bitset  ── lacks bit ──► request dropped
        │                                                          (app sees a
        │ holds bit                                                 secure device
        ▼                                                           picker instead,
maps the device MMIO window directly into the app's                 never a crash)
address space  →  app now reads/writes hardware registers
directly, zero-copy, with NO further kernel involvement
per frame and NO recurring "allow?" prompt
```

The capability is granted **once** — at install from the manifest for
Marketplace apps, or via a single fast HUD confirmation for sideloaded apps —
and then the data path is genuinely unmediated: a 4K camera feed or a
1000 Hz controller streams straight into app memory. The security is that a
capability the app never received cannot be exercised at all: the bitset check
in `sys_hardware_passthrough` returns a hard denial, and there is no mapping to
abuse. An app you never gave the microphone to physically cannot open it, no
matter how it is packaged or where it came from.

To keep this safe on real hardware, every DMA-capable device sits behind its own
IOMMU domain, so "unrestricted" MMIO means unrestricted access to *that device's
registers* — never to arbitrary system memory.

---

## SECTION 3 — The Hybrid Radical CLI & Shell Environment

### 3.1 Design: the Outrun Shell (`osh`)

`osh` is a GPU-rendered, object-aware shell. It carries structured objects
through pipelines like PowerShell, keeps the muscle-memory ergonomics and
scripting compatibility of Zsh/POSIX, and renders in the compositor so it can
show inline sparklines, progress rings, and syntax-highlighted structured output
without leaving the terminal grid.

Core model: **commands emit typed object streams, not just bytes.** A pipeline
stage receives an array of records (each a map of typed fields). A final stage
with no consumer auto-renders the records as an aligned table. Crucially, any
stage may request a **byte view** of the stream (`| bytes`), at which point the
records serialize to their text form — this is the bridge that keeps every
existing POSIX tool (`grep`, `awk`, `sed`, `jq`) working unchanged inside `osh`.

```
records ──► [ osh-native stage ]──► records ──► [ | bytes ]──► text ──► grep ──► text
```

The renderer is a shader over a glyph atlas: monospace grid, ligature-aware,
with per-cell background so structured output can shade columns. Scrollback is
a ring of records, so you can re-query old output (`$LAST | where size > 1MB`)
without re-running the command.

### 3.2 Administrative task syntax

**Task A — query local hardware pass-through addresses.** `hw` emits device
records; each row is a live object you can pipe further.

```
outrun ~ ▸ hw ls --passthrough

  DEVICE        MMIO_BASE     LEN      HOLDER        CAP           STATE
  ───────────   ───────────   ──────   ───────────   ───────────   ──────
  camera0       0xF0000000    1.0 MiB  stream-app    CAMERA        DIRECT
  microphone0   0xF0100000    64 KiB   mixer         MICROPHONE    DIRECT
  controller0   0xF0200000    4 KiB    —             CONTROLLER    FREE

  3 devices · 2 mapped direct · pipe to inspect: `hw ls --passthrough | where holder == "stream-app"`

outrun ~ ▸ hw ls --passthrough | where state == DIRECT | select device, holder

  DEVICE        HOLDER
  camera0       stream-app
  microphone0   mixer
```

**Task B — inspect active A/B root slots.** `slot` reads the atomic update
engine's state directly.

```
outrun ~ ▸ slot status

  SLOT   ROLE      VERSION        ROOT_HASH             HEALTH
  ────   ───────   ───────────    ──────────────────    ──────
  A      ACTIVE    0.3.0-metal    4a1bc893f4f85abe      ✓ verified
  B      PASSIVE   0.3.1-metal    947e38d76ebf0f9b      ✓ staged, hash-checked

  next boot: A (unchanged) · `slot flip` to activate B reboot-free for userspace
  rollback armed: yes (auto-revert to A if B fails liveness within 90s)

outrun ~ ▸ slot diff A B | where change == modified | head 3

  PATH                         CHANGE      OLD_HASH    NEW_HASH
  /sys/lib/libcompositor.so    modified    3f9c…       a17e…
  /sys/svc/gesture-engine      modified    88 b1…      c204…
  /sys/lib/libglass.so         modified    12de…       9f45…
```

**Task C — search the chronological AI Time-Stream.** `ts` queries the local
vector index; results are records with a timestamp, a semantic score, and a CAS
hash you can open or restore.

```
outrun ~ ▸ ts find "the chart Sarah sent me about Q3" --since 30d

  WHEN              SCORE   KIND    TITLE                     FROM     CAS_HASH
  ───────────────   ─────   ─────   ───────────────────────   ──────   ────────────
  Mar 14 14:22      0.94    image   q3_revenue_chart.png      Sarah    868d9e65…
  Mar 14 14:19      0.71    email   "Q3 numbers for review"   Sarah    c128a5ea…
  Feb 28 09:05      0.55    doc     Q3_briefing.pdf           —        3f7a0011…

  3 results · open: `ts open 868d9e65` · restore workspace: `ts restore 868d9e65 --with-context`

outrun ~ ▸ ts find "programming session last night" | ts restore $0.first --with-context
  ↳ restoring canvas state from Mar 20 23:30: Index.rs, Build_Output.txt, 4 browser tabs, debugger
```

### 3.3 Hardened security without slowing developers

**Capability tokens per shell tab.** Each `osh` tab is a process with its own
Capabilities bitset (the same structure enforced in `caps.rs`). A fresh tab
starts with `CAP_FILESYSTEM` scoped to the current canvas project and nothing
else — no camera, no raw network, no view of other tabs' processes. Elevating is
explicit and per-tab:

```
outrun ~ ▸ cap grant net --scope this-tab --ttl 1h
  ↳ CAP_NETWORK granted to tab pid 4471 for 60m (auto-revokes; `cap drop net` to end early)
```

**Isolated namespaces per tab.** Each tab gets a private mount/PID/network
namespace. A destructive command in one tab (`rm -rf` inside a project) cannot
reach another tab's project, and a runaway process is visible and killable only
within its own tab. This is container-grade isolation applied at the granularity
of a terminal tab, established in well under a millisecond at tab spawn so it is
invisible to the user.

**POSIX compatibility is preserved** because the namespace + capability layer
sits *below* the command interface: scripts see a normal filesystem and normal
processes; they simply cannot see or touch anything outside their grant. A
standard `bash` script run under `osh` executes unchanged — it just runs inside
the tab's sandbox, with the `| bytes` bridge handling any structured input it is
handed. Developers pay no syntax tax and lose no tooling; the isolation is
ambient.

---

## SECTION 4 — The Integrated Chronological Context Workspace

### 4.1 Time-Stream ↔ Comm-Deck: the shared substrate

The Time-Stream (chronological file/history engine) and the Comm-Deck
(protocol-agnostic chat/email/notification pipeline) are two faces of one local
data core. They share three services: the **CAS store** (every artifact — an
attachment, a document, a message body — is content-addressed, per the
`cas_vfs.rs` prototype), the **edge AI embedder** (turns artifacts into vectors
on idle NPU/GPU cycles), and the **event log** (a single append-only timeline of
typed events that both surfaces render).

Every event flowing through either surface is one record type:

```c
struct StreamEvent {
    uint64_t timestamp_ns;      // when it entered the system
    uint32_t kind;              // MSG | FILE | STATE | NOTIFY
    uint32_t source_protocol;   // SIGNAL | MATRIX | EMAIL | SMS | LOCAL
    uint64_t contact_id;        // resolved cross-protocol identity
    uint64_t cas_hash;          // content-addressed body/attachment
    uint64_t vector_id;         // handle into the local embedding DB (0 = pending)
    uint64_t workspace_ref;     // canvas state to restore, if any
    uint16_t priority_lane;     // ACTIONABLE | PASSIVE | MUTED
};
```

Because both surfaces read the same `StreamEvent` log keyed by the same
`contact_id` and `cas_hash`, a message and the file it references are already
linked with no extra work: the Comm-Deck shows the message, the Time-Stream
shows the file, and both point at the same CAS hash and the same moment on the
timeline.

### 4.2 End-to-end data flow: message arrival to timeline

```
  ┌────────────────────────────────────────────────────────────────────────────┐
  │  t+0 ms   INGRESS                                                            │
  │  Signal/Matrix/Email/SMS frame arrives at the protocol-agnostic Comm-Deck   │
  │  gateway. Normalized into a StreamEvent{kind=MSG, source_protocol=…,         │
  │  contact_id=resolve(sender)}.                                               │
  └───────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
  ┌────────────────────────────────────────────────────────────────────────────┐
  │  t+1 ms   CONTENT-ADDRESS                                                    │
  │  Message body + any attachment are written to the CAS store (write_file).   │
  │  Deduplicated automatically; cas_hash filled into the event. If the         │
  │  attachment already exists (someone re-sent it), 0 new bytes are stored.    │
  └───────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
  ┌────────────────────────────────────────────────────────────────────────────┐
  │  t+2 ms   PRIORITY LANE + INSTANT SURFACE                                    │
  │  Rule engine assigns priority_lane. Event is appended to the event log and  │
  │  BOTH surfaces update immediately:                                          │
  │     • Comm-Deck: message appears in the contact's unified thread            │
  │     • Time-Stream: a provisional card appears at "now" (vector_id = 0)      │
  │  The user sees the message with NO wait on AI.                              │
  └───────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
  ┌────────────────────────────────────────────────────────────────────────────┐
  │  t+… (idle)   LOW-PRIORITY EDGE EMBEDDING                                    │
  │  On the next idle NPU/GPU window (yields instantly if a game/creative app   │
  │  claims hardware), the embedder reads the CAS body, produces a multimodal   │
  │  vector, writes it to the local vector DB, and patches vector_id into the   │
  │  event. Nothing left the machine.                                           │
  └───────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
  ┌────────────────────────────────────────────────────────────────────────────┐
  │  t+… settled   SEMANTIC INDEXED                                             │
  │  The provisional Time-Stream card is now fully searchable by meaning:       │
  │  `ts find "chart Sarah sent about Q3"` resolves to it via vector_id.        │
  │  Auto-tags (people, project, content) are attached. No manual filing ever.  │
  └───────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
  ┌────────────────────────────────────────────────────────────────────────────┐
  │  DEEP LINK   (when the user clicks the message later)                        │
  │  workspace_ref resolves: the infinite canvas snaps back to the exact files, │
  │  tabs, and window layout that were open when this message arrived, because  │
  │  the event captured the canvas state hash at ingress.                       │
  └────────────────────────────────────────────────────────────────────────────┘
```

### 4.3 Why the integration is automatic, not bolted-on

The administrative "magic" — a teammate writes *"update that layout we looked at
last Tuesday"* and the right file surfaces — falls out of the shared substrate
with no special-case code. The incoming message is a `StreamEvent` with a
`contact_id`; the local semantic AI embeds its text and runs a vector query
against the Time-Stream; the highest-scoring event from "last Tuesday" with that
same `contact_id` is the design file; its `workspace_ref` restores the session.
Comm-Deck and Time-Stream never call each other directly — they simply read and
write the same content-addressed, vector-indexed event log, which is what makes
the whole desktop feel like one contextual workspace instead of a pile of apps.

---

## Prototype cross-reference

The subsystems referenced above are implemented as compiling, runnable code in
the `subsystems/` directory of this repository:

- **§1.1 contrast math / §4** content addressing → `subsystems/cas_vfs.rs`
  (block-level dedup, stable content hashes, verified 4× compaction).
- **§2.3** capability-gated passthrough → `subsystems/caps.rs`
  (grant-vs-drop enforced by bitset on `sys_hardware_passthrough`).
- **§4.2** zero-copy delivery to isolated workspaces → `subsystems/packet_router.cpp`
  (SPSC ring, payloads copied once at ingress, delivered by pointer).

Every mechanism specified here that could be reduced to running code has been,
and each demo's invariants are asserted at runtime rather than asserted in prose.
