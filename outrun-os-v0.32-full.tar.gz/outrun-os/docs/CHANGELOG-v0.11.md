# Outrun OS v0.11 — Phase 3: async IRQ routing + virtio-net + zero-copy parse

The network card now raises real interrupts that the kernel routes to a specific
blocked thread, and a zero-copy parser reads frames straight out of the RX ring.

## virtio-net driver (modern virtio 1.0)
- Full bring-up: PCI cap parse (common/notify/isr/device), MMIO map, bus-master,
  reset -> ACK -> DRIVER -> feature negotiation (VIRTIO_NET_F_MAC + VERSION_1) ->
  FEATURES_OK -> DRIVER_OK. MAC read from device-config.
- RX and TX split virtqueues; 16 receive buffers posted; the device is also
  registered for ring-3 passthrough (so the usermode MAC-read demo still works).

## Async interrupt routing (Ring-0 -> blocked thread)
- PCI INTx is shared, so the IRQ table now holds a handler chain per line; each
  device's top half checks its own ISR-status register. (This also fixed a clash
  where virtio-blk and virtio-net share IRQ 11.)
- TOP HALF: read the NIC ISR (de-asserts INTx), flag the softirq.
- BOTTOM HALF: drain the RX used ring and WAKE the exact thread parked on
  NET_RX (by TID) — a hardware interrupt transitions the owning thread from
  BLOCKED to RUNNABLE.
- sys_wait_event(NET_RX): capability-gated (CAP_NETWORK) syscall / kernel call
  that parks the caller until the NIC interrupts. Also exposed as syscall #9.

## Zero-copy packet parse (Phase 3 item 2)
- The demo `netd` thread (holding CAP_NETWORK) transmits an ARP request for the
  gateway, then blocks on sys_wait_event. When QEMU's SLIRP replies, the RX IRQ
  wakes netd, which parses the Ethernet/ARP frame IN PLACE (pointers into the RX
  buffer, no memcpy) and prints the gateway's MAC.

## Proof (docs/net-boot.log)
- `[vnet] DRIVER_OK — rxq 16 txq 16, INTx IRQ 11 — READY`
- `[netd] tid2 holds CAP_NETWORK; TX ARP who-has 10.0.2.2`
- `[netd] sys_wait_event(NET_RX): parking until the NIC interrupts...`
- `[netd] woken by IRQ; RX 76 bytes, ethertype 806`
- `[netd] ARP reply: 10.0.2.2 is-at 52:55:0a:00:02:02 (parsed in place)`
The full boot (CAS persistence, scheduler, VFS, exec-from-CAS, ring-3) is
unchanged and reaches the shell. Both virtio-blk and virtio-net operate on the
shared IRQ line simultaneously.

## Scope / next
- ARP-level round trip proves the interrupt/wake path; the IP/UDP router and a
  full RX buffer-recycle loop are the next build. The waiter is demonstrated with
  a kernel thread; wiring sys_wait_event to a blocking ring-3 process (process as
  a first-class scheduler thread) is the follow-on.
