# Outrun OS v0.26 — PS/2 mouse driver + cursor coordinate translation locked down

The canvas gains its second input modality, and the screen<->world transform that
all modalities share is now pinned by automated invariants.

## PS/2 mouse driver (IRQ 12)
- Full auxiliary-device bring-up through the 8042: enable aux port (0xA8), read
  the config byte, set IRQ12 + enable the aux clock, set defaults (0xF6), enable
  reporting (0xF4) — every command ACK-checked.
- IntelliMouse detection via the 200/100/80 sample-rate knock: the device reports
  id 3, so we run 4-byte packets WITH a scroll wheel (4-bit signed Z, sign-
  extended). Falls back to 3-byte packets on a plain mouse.
- The IRQ handler stays tiny: it validates the sync bit (bit 3), resyncs on a bad
  packet boundary, drops overflow packets, sign-extends the 9-bit X/Y deltas,
  flips PS/2's up-positive Y, and accumulates deltas + button state. All
  coordinate work happens in the canvas, not the top half.
- Registered through the existing register_irq/pic_unmask path (IRQ12 needs the
  slave PIC + cascade, which pic_unmask already handled).

## Cursor coordinate translation
- s2wx/s2wy: the exact inverse of the w2sx/w2sy projection.
- canvas_zoom_at(sx, sy, factor): zoom about a screen point, keeping the world
  point under it fixed — the anchored-zoom that makes wheel-zoom feel right.
- canvas_pick(): world-space hit testing, topmost (focused) window first.
- Interactions: wheel zooms at the cursor; left-drag on a window moves it in
  WORLD space (screen delta / zoom, so drag tracks the pointer at any zoom);
  left-drag on empty canvas pans; clicking a window focuses it. The cursor
  changes colour by mode (amber idle / mint dragging a window / magenta panning).

## `cursor` command — 6/6 invariants
- screen->world->screen round-trips at 6 zoom levels x 25 screen points: worst
  error 1 px (fixed-point rounding).
- world->screen->world round-trips stable.
- **zoom-at-cursor keeps the world point pinned under the pointer: worst drift 0
  world units across 150 zoom operations.**
- Panning preserves projected size (no drift); 2x zoom exactly doubles it.
- Hit-testing agrees with rendering: each window's centre picks that window.

## Verified with a real mouse, not a simulation
Driving QEMU's PS/2 mouse from the monitor (9 x mouse_move -30 -22) moved the
cursor from its default (512,384) to exactly (242,186) — pixel-exact against the
predicted 512-270, 384-198. That exercises the real IRQ 12 -> packet decode ->
sign extension -> delta accumulation -> cursor path.
Screenshot: docs/spatial-canvas-cursor.png.

## Honest scope
- Two of three input modalities now: keyboard + mouse. Camera/hand-gesture input
  is still absent (it needs the local-AI landmark pipeline from the blueprint),
  but it would feed the same cursor/transform layer this milestone locks down.
- No cursor acceleration curve and no mouse-driven window resize yet.

## Status
All prior suites remain green: 19/19 validation, 21/21 invariants, 10/10 stress,
8/8 fuzz, 2/2 iommu, 11/11 capdma, 6/6 cursor, ring-3 userspace driver TX
completed, plus CAS, DHCP, compositor, ring-3 demos, canvas and the shell.
Zero exceptions.
