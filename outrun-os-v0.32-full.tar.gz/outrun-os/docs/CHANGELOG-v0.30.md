# Outrun OS v0.30 — input routing to ring-3 surfaces

A surface stops being a picture and becomes an application: the compositor now
delivers input to the process that owns the window, translated into that app's
OWN pixel coordinates.

## Routing
- Each surface carries a 16-entry event queue (struct sevent {type,x,y,code}).
- surface_route(sx, sy, type, code) is the exact inverse of the compositor's
  placement: screen -> the window's projected rect (via the live camera) -> the
  panel's content rect -> the app's surface pixel grid. Topmost/focused first.
- canvas_mouse() routes a press over a surface-backed window to its owner
  instead of starting a window drag — the app gets the click, not the shell.
- SYS_SURFACE_POLL(slot, *out_event) (syscall 14): CAP_FRAMEBUFFER gated, and
  additionally OWNER-ONLY — a process cannot poll a surface it does not own
  (returns -13). The out pointer goes through access_ok, so a hostile pointer
  gets EFAULT, not a kernel write.

## Proof
Three clicks were driven through the real driver path (mouse button + cursor
state, then canvas_mouse()), at screen (470,400), (560,440), (660,470). The app
received them in ITS coordinates and redrew itself:

    [surfin ] routed 3 clicks into surface 4's queue (surface-local coords)
      [app:r3] event type 1 at surface-local (31,20)
      [app:r3] event type 1 at surface-local (91,64)
      [app:r3] event type 1 at surface-local (157,97)
      [app:r3] handled 3 routed events and redrew itself

Proportional and monotonic against the screen coordinates, through a camera at
88% zoom — the transform chain from v0.26/v0.27 carries all the way into the
app's pixel space. The app then draws its own markers at those points and the
compositor recomposites. Screenshot: docs/surface-input.png.

## Honest scope
- Clicks only: keyboard events have a type code reserved but are not yet routed.
- The app is re-entered to drain its queue (ring-3 processes still run on the
  main thread rather than as scheduler threads), so this is not yet a live event
  loop — the app reacts between canvas passes, not during one.
- Still single-buffered, and surfaces are still not reclaimed on owner exit.

## Status
All eight suites still report zero failures — 19/19 validation, 21/21 invariants,
10/10 stress, 8/8 fuzz, 2/2 iommu, 11/11 capdma, 6/6 cursor, 8/8 kinetic — plus
the ring-3 NIC driver's hardware TX, CAS, DHCP, canvas and shell.
