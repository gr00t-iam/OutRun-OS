# Outrun OS v0.19 — stack hardening: guard pages + stack canaries

Seals the last major ring-3 → kernel corruption vector: stack overflows are now
trapped by guard pages, and stack smashing is caught by compiler-injected
canaries. Two more checks join the stress suite (now 10/10).

## Guard pages (ring-3 stacks)
- The ring-3 stack is expanded to 16 KiB (4 pages) with an explicit, unmapped
  guard page directly below it.
- The #PF handler now reads CR2 and, for any fault from ring 3, terminates the
  offending task instead of panicking — switching back to the kernel address
  space and unwinding via resume_kernel. A fault in the guard-page window is
  reported as a stack overflow. A ring-3 stack bomb (push until the stack walks
  off the bottom) is trapped exactly at USTK_V-8 and the task is killed with the
  kernel untouched.
- Any ring-3 excursion now restores interrupts on return (both SYS_EXIT and the
  fault-unwind path can land with IF cleared).

## Stack canaries (whole kernel)
- Built with -fstack-protector-strong: the compiler injects prologue/epilogue
  canary save+check into every function with a stack buffer.
- __stack_chk_guard is seeded with RDTSC-derived entropy at boot; __stack_chk_fail
  halts the core on a smash (or, in test mode, recovers via __builtin_longjmp).
- Per-thread canaries: each thread gets its own canary (entropy at creation,
  stored in the PCB) and the scheduler saves/restores the active guard across
  every context switch, so a canary is valid for the thread that owns the frame
  even under heavy preemption. Verified: the preempted worker/spinner threads
  never raise a false __stack_chk_fail.

## Also hardened
- usermode_init (user-segment GDT + TSS + SYSCALL MSRs) now runs before the
  stress suite, since ring-3 entry is a prerequisite for the guard-page test.

## Stress suite — now 10/10
Adds: (8) ring-3 stack overflow trapped by guard page; (9) stack canary detects
a local buffer overflow. Plus the existing W^X/NX/WP, invlpg staleness, 20000
CR3 switches under preemption, page-table auditor, and allocator fault injection.

## Proof (docs/stack-hardening-boot.log)
Full boot green: 19/19 validation, 21/21 invariants, 10/10 stress, DHCP, animated
compositor, ring-3 (now on guarded stacks) with register preservation, and the
shell. Verified on BIOS ISO and the NVMe/UEFI install image.

## Next
With stack boundaries sealed, syscall-argument fuzzing is the natural next step;
a periodic descriptor-table sweep can fold into the scheduler tick.
