# Outrun OS v0.23 — capability-bound IOMMU DMA domains

Binds the IOMMU to the capability system. Granting a process a device no longer
just maps its MMIO registers: the device is simultaneously confined by hardware
to a DMA domain containing ONLY that process's memory. This is what makes the
blueprint's "unrestricted hardware access" safe by construction — an app drives
the device directly, and the device physically cannot reach the kernel or any
other process.

## How it works
- Every kdev entry now carries its PCI source-id (BDF).
- On a successful sys_hardware_passthrough (which already requires BOTH
  CAP_HW_PASSTHROUGH and the device-specific capability), the kernel calls
  iommu_attach_proc_domain(): it builds a per-process second-level page table by
  walking the process's OWN page tables and identity-mapping only its USER RAM
  frames — skipping the shared kernel identity map, the kernel MMIO window, and
  device MMIO (PCD) pages — then points the device's context entry at that table
  with a per-process domain id (16 + proc index) and invalidates the caches.
- iommu_detach_to_kernel() returns a device to the kernel's identity domain
  (revocation).
- New second-level helpers: slpt_map4k() (creates levels on demand, adapts to the
  3- or 4-level AGAW chosen at init) and slpt_lookup() (for verification).

## `capdma` command — 11/11
Structural:
- The capability holder is granted the device's MMIO, and the grant creates a
  private DMA domain for the owner.
- The device's context entry points at the owner's domain and carries the owner's
  domain id.
Reachability (what the device can and cannot touch):
- The owner's own RAM page IS reachable.
- Another process's RAM page is NOT reachable.
- Kernel memory is NOT reachable.
- The kernel's virtqueue memory is NOT reachable.
- Device MMIO was not mapped into the DMA domain.
Live enforcement + revocation:
- The confined device attempts a real DMA into kernel memory and is BLOCKED by
  hardware, with the fault naming it:
    blocked: device 0:3.0 tried read at 0x1017000 — outside pid 16's domain
- Revoking the grant returns the device to the kernel domain.

## Note on the single live-fault test
A blocked DMA puts a QEMU virtio device into its "broken" state, so a device can
only be made to fault once per boot. The live proof therefore runs exactly once,
in `capdma` (the more meaningful demonstration); `iommu` keeps the hardware
status checks (GSTS.TES / GSTS.RTPS) and reports the fault-recording geometry.

## Honest scope
- The grant is exclusive by nature: once a device is confined to a process's
  domain, the KERNEL's own driver for that device can no longer DMA to it (its
  virtqueue is outside the domain). That is correct passthrough semantics, but
  the kernel driver does not yet formally relinquish the device on grant — a real
  handoff would quiesce the in-kernel driver first.
- IOVA scheme is identity (device sees physical addresses of the owner's frames).
- Domains are rebuilt only on first grant; pages mapped into a process after its
  domain is built are not added yet (no live domain update).
- VT-x remains unavailable in this environment (no KVM; TCG does not emulate
  VMXON) and is reported honestly, not faked.

## Verified
- q35 + intel-iommu (BIOS ISO): 19/19 validation, 21/21 invariants, 10/10 stress,
  8/8 fuzz, 2/2 iommu, 11/11 capdma, plus CAS + DHCP (DMA through the IOMMU),
  compositor, ring-3, shell. Zero exceptions.
- REGRESSION: no-IOMMU i440fx boot still fully green; capdma reports the platform
  has no IOMMU and degrades gracefully.
