# Outrun OS v0.17 — core security boundary hardening (exhaustive invariants)

Deepens validation from spot-checks to exhaustive coverage of the user/kernel
boundary, plus the hardening fixes that coverage surfaced. This locks the
isolation guarantees down before any virtualization layer is considered.

## Hardening fixes
- sys_hardware_passthrough dispatch now REJECTS out-of-range device handles
  (previously it silently fell back to a default device); the explicit 0xFFFF
  "default device" sentinel is preserved.
- Process table raised (MAX_KPROC) so the validation harness cannot exhaust it.

## Exhaustive isolation & hardening invariants (`invariants` command)
21 checks, all passing, run at boot:

Capability isolation (the escalation invariant):
- For every gated syscall, the ENTIRE 64-entry capability space is swept; any
  mask lacking the required bit MUST be denied. 192/192 denial checks held —
  proving no combination of other capabilities can escalate into a gated
  operation.

Cross-process address-space isolation:
- The same virtual address resolves to each process's OWN physical frame;
  processes get physically distinct frames; a page mapped only in A is not
  present in B's address space at all.

Kernel/user separation at the PTE level:
- User pages carry PRESENT + USER + WRITE; the kernel's own pages are reachable
  through the shared identity map but are SUPERVISOR-only (no USER bit), so
  ring 3 cannot touch kernel memory. Processes share exactly the identity map
  (PML4[0]) and the device-MMIO window (PML4[0xC0]) and keep a PRIVATE user
  region (PML4[0xA0]).

Passthrough hardening (two-level capability gate):
- Invalid device handles rejected; a device is granted only with BOTH
  CAP_HW_PASSTHROUGH and the device-specific capability; the granted MMIO page
  is USER + cache-disabled and is absent from any unrelated address space.

## Register-preservation self-test (ring 3)
- The ring-3 program loads sentinels into all callee-saved registers
  (rbx, r12-r15), crosses the real SYSCALL/SYSRET boundary, and verifies they
  survive — "callee-saved regs survive SYSCALL: PASS" for every ring-3 process.

## Proof (docs/invariants-boot.log)
The full 21/21 invariant run + 192/192 capability sweep + register-preservation
PASS. The prior suites (19/19 production validation) and the whole system
(scheduler, VFS, net, DHCP router, compositor, Time-Stream) remain green and
the system reaches the shell. Install image rebuilt.

## Status
Core security boundary is now exhaustively verified: capability isolation over
the whole capability space, cross-process memory isolation, kernel/user PTE
separation, passthrough two-level gating, and register preservation across the
ring boundary. This is the stable foundation to build on.
