# Outrun OS v0.29 — ring-3 application surfaces

The compositor stops being the application. An unprivileged ring-3 process now
owns a canvas window's pixels: it asks the kernel for a surface, renders into it
with zero kernel involvement, and the compositor merely places the result.

## The model
- `SYS_SURFACE_CREATE((w<<16)|h, slot)` (syscall 13), gated on CAP_FRAMEBUFFER:
  allocates a physically contiguous, zeroed pixel buffer, maps it USER|WRITE|NX
  into the calling process at a dedicated surface window (0x530000000000), and
  binds it to a canvas slot with the caller recorded as owner.
- `struct surface { phys, w, h, used, owner }` — the kernel tracks who owns which
  window's pixels.
- canvas_window() composites a bound surface (nearest-neighbour scaled to the
  panel at the current zoom) instead of drawing kernel content, and labels it
  "RING-3 SURFACE". Unbound windows keep the live system surfaces from v0.28.

## The application (user/init.c, role 2)
Runs entirely at ring 3: requests a 200x120 surface, then renders a cyan core, a
checker field, a magenta border and a mint bar directly into its own mapped
pixels. The kernel draws none of it.

## Verified by pixels, not by claims
The app's checker pattern (0x101828) is a colour the kernel palette never uses.
After boot it appears composited at x 428-719, y 384-488 — exactly the
VIDEO-EDITOR panel — 12,027 pixels of it:

    [surface] handing canvas window 4 to unprivileged pid 17
    [surface] pid 17 owns surface 4 (200x120) at user vaddr 0000530000000000
      [app:r3] 200x120 surface rendered ENTIRELY at ring 3

Screenshot: docs/ring3-surface.png.

## Honest scope
- Single-buffered: the app renders once and exits; the kernel keeps compositing
  the buffer. No double-buffering, damage tracking, or frame synchronisation, so
  a continuously-animating app could tear.
- Surfaces are not yet reclaimed when their owner exits (the buffer outlives the
  process by design here, but a real system needs a lifecycle).
- The app cannot receive input events routed to its window yet — it renders, it
  does not interact.
- Composited by CPU blit with a per-pixel divide; fine at this size, but it is
  not a fast path.

## Status
All eight suites still report zero failures — 19/19 validation, 21/21 invariants,
10/10 stress, 8/8 fuzz, 2/2 iommu, 11/11 capdma, 6/6 cursor, 8/8 kinetic — plus
the ring-3 NIC driver's hardware TX, CAS, DHCP, canvas and shell. Zero exceptions.
