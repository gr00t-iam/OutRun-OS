# Outrun OS Security Model

## The tension, resolved

The charter demands two things that read as contradictory: applications get
direct, unrestricted, zero-copy hardware access, and the system is genuinely
secure even for unvetted sideloaded software. The resolution is temporal.
Security lives at grant time; freedom lives at use time. Every app launches with
zero capabilities. Acquiring one is a single, fast, non-nagging event — a grant
the user confirms once through a system HUD gesture, or that a Nexus manifest
declares and the user accepts at install. After the grant, the data path is
exactly as unrestricted as the manifesto promises: no per-frame checks, no
recurring prompts, no kernel in the loop. A capability, once granted, persists
until the user or kernel revokes it, so the "endless corporate prompts" the
charter rejects never appear — but a keylogger that was never granted the input
stream physically has no mapping to read, no matter how it was installed.

This is why sideloading can be a native right rather than a risk: Nexus apps and
random P2P apps run on identical sandbox infrastructure, and an unvetted binary
with no grants can touch nothing. Malware isn't detected here; it's unfunded.

## Threat model and answers

Against a malicious application: it starts with no file system view, no device
mappings, no network, and cannot see other processes. Any resource it touches is
one the user granted. Revocation is unilateral — a generation bump plus page
unmap — so a grant is never a permanent surrender.

Against a compromised or buggy driver: drivers are user-space processes with only
their own device's capabilities. A driver crash is contained and restarted
(demonstrated live: SIGSEGV to restart in 18 ms). On real hardware, DMA-capable
devices sit behind the IOMMU so a hijacked device cannot scribble over arbitrary
physical memory — this is mandatory, not optional, for the unrestricted-MMIO
model to be safe.

Against forged capabilities: handles are (slot, generation) references to
kernel-owned records, not bearer tokens. There is nothing to steal that grants
authority by possession; the kernel table is the sole source of truth and the
kernel established every mapping itself.

Against a hostile update server or tampered download: updates stage into the
passive slot and must match the manifest content hash before the flip; the demo
deliberately corrupts a download and shows it rejected with the active slot
untouched. Production adds signature verification over the manifest itself and
anti-rollback version counters.

Against camera surveillance via the gesture engine: the gesture service is the
only always-on holder of raw pixels, and it exports derived landmark events
exclusively. No application receives frames as a side effect of gestures being
enabled; raw pixel access is always its own explicit grant, indicated by a
hardware-backed on-air light the compositor cannot suppress.

## What the prototype does not yet enforce

Honesty about the simulation's edges: revocation here is observed by the holder
(its next access check fails) rather than enforced (pages unmapped under it) —
bare metal does both. Process isolation stands in for address-space isolation
configured by our own kernel. The seqlock and generation protocols are the real
designs; the enforcement mechanisms beneath them are the host OS's until the
kernel boots on hardware. Formal verification of the capability table and IPC
state machines is roadmap work, targeted before any external code runs on the
system.
