# Outrun OS v0.10 — Phase 2: Virtual File System over CAS

Named, read/write files layered on the content-addressable store, with
capability-gated file syscalls for ring-3 and an exec that loads ELFs straight
from storage instead of the GRUB module.

## VFS layer
- On-disk directory region added to the CAS volume (superblock v2): a table of
  dirents {name, len, per-512B-block content hashes, whole-file hash}.
- A file is a name + an ordered list of block hashes; blocks live in CAS, so:
  - files span multiple blocks (readme = 1400 bytes across 3 blocks, verified);
  - identical content is stored once (a duplicate file adds 0 new blocks);
  - writes are copy-on-write (new content -> new hashes -> new file_hash; the
    name simply repoints; old blocks are immutable).
- Directory persists: flushed on change, reloaded on mount.

## Capability-gated file syscalls (ring-3)
- Extended the syscall ABI to 3 user args (a2 in RDX) so read/write can carry
  (fd, buf, len).
- New syscalls, each gated by CAP_FILESYSTEM via the Rust cap engine:
  sys_open(5), sys_read(6), sys_write(7), sys_close(8).
- Orthogonal capabilities demonstrated at ring 3 from the same ELF:
  - stream-app (HW_PASSTHROUGH): reads virtio MMIO, file access DENIED.
  - sketchy-app (FILESYSTEM): passthrough DENIED, reads a file from the VFS.

## sys_exec from storage
- exec_from_cas(name): reads an ELF's bytes back out of CAS (by VFS name ->
  content hashes -> blocks) into a buffer, then runs the existing ELF loader —
  no GRUB module involved.
- Proof: the kernel stores the user ELF into the VFS as "init", then a third
  process is loaded from CAS ("read 5624 ELF bytes from CAS ... not a GRUB
  module") and runs at ring 3, exercising BOTH hardware passthrough (real
  virtio-net MAC 52:54:00:ab:cd:ef) and a VFS file read.

## Proof (docs/vfs-boot.log)
Multi-block store + read-verify, copy-on-write hash change, cross-file dedup
(+0 blocks), per-process capability grant/deny at ring 3, and exec-from-CAS.
Verified on BIOS + UEFI; CAS persistence and the preemptive scheduler are
unchanged; the system reaches the shell.

## Scope / next
- Files up to 8 KiB (16 block-hashes per dirent), 16 files, single directory —
  all natural to grow into a multi-level index later. Read/write are whole-file
  (offset tracking is stubbed). Ring-3 I/O runs on the main thread's context;
  turning ring-3 processes into first-class scheduler threads is the next step.
