# Outrun OS v0.6 — Phase 1: real disk I/O (virtio-blk)

The kernel can now read and write real disk sectors over a virtio-blk PCI
device, instead of depending only on GRUB-loaded RAM modules.

## The virtio-blk driver (modern virtio 1.0, split virtqueue)
- PCI discovery: dispatches virtio devices by class — mass storage (0x01) to the
  new block driver, network (0x02) to the existing passthrough probe.
- Maps the device's MMIO BAR into kernel space (uncached PTEs) and parses the
  virtio vendor capabilities for the common-config, notify, and device-config
  structures (incl. the notify offset multiplier).
- Enables PCI memory-space decode AND bus-mastering (the device DMAs).
- Full status handshake: RESET -> ACKNOWLEDGE -> DRIVER -> feature negotiation
  (requires VIRTIO_F_VERSION_1) -> FEATURES_OK (verified) -> DRIVER_OK.
- Reads the capacity from device-config.
- Builds the split virtqueue by hand: descriptor table, avail ring, and used
  ring in DMA-visible physical memory, wired via queue_desc/queue_driver/
  queue_device, then queue_enable.
- Requests are three chained descriptors (16-byte header, 512-byte data,
  1-byte status). Submits on the avail ring, kicks the notify register, and
  BLOCKS by polling the used ring, then checks the status byte.

## Public API
- `int virtio_read_block(uint64_t sector, void *buffer);`
- `int virtio_write_block(uint64_t sector, const void *buffer);`
  Both return 0 on success, negative on error/timeout.

## Proof (docs/virtio-blk-boot.log)
Booting with a 4 MiB virtio-blk disk that has a signature at sector 2:
- discovery: `vendor 1af4 device 1042 class 100` (modern virtio-blk, mass storage)
- `capacity: 8192 sectors (4 MiB)` read from device-config
- `read sector 2 -> "OUTRUN-DISK-SIGNATURE-OK"` — reading real pre-existing
  on-disk data
- `wrote + read back sector 0 ... verify MATCH` — full write/DMA/read round-trip
- The write is durable: after the VM exits, sector 0 of the host image contains
  "OUTRUN-WROTE-THIS-SECTOR..." — a genuine DMA write to physical storage.
Verified under both SeaBIOS (BAR at 0xFE000000) and OVMF/UEFI. Falls back
gracefully with a clear message when no virtio-blk device is attached.

## Build / run
- `make qemu` now auto-creates a signed test disk and attaches it as virtio-blk.
- Shell command `disk` re-runs the read/write round-trip on demand.

## Also staged (not yet linked): polyglot components
- `rust/cap_engine.rs` — a no_core Rust translation unit (FNV-1a CAS hash +
  capability check) that compiles to real machine code with this toolchain.
- `cpp/ipc_ring.cpp` — a freestanding C++ SPSC ring buffer with an extern "C"
  surface. These are the beginnings of the unified C/C++/Rust/asm boot image.
