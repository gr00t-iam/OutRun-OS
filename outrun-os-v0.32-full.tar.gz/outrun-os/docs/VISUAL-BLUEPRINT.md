# Outrun OS — Metropolis-Terminal Visual Design Blueprint

Original visual language. No borrowed marks, characters, logos, or property from
any existing film, game, or franchise. Every color, glyph, and motion curve below
is defined from first principles as a technical parameter.

Design roles: Principal UI/UX Architecture + Lead Graphics Shader Development.

---

## SECTION 1 — The Metropolis-Terminal Palette & Shader Math

### 1.1 Dual-theme color architecture (exact hex)

**Theme A — High-Contrast Neon** (default; obsidian + electric accents)

| Token                 | Hex        | Role                                          |
|-----------------------|------------|-----------------------------------------------|
| `bg.obsidian.0`       | `#05060A`  | deepest desktop void                          |
| `bg.obsidian.1`       | `#0A0D14`  | panel base plate                              |
| `bg.obsidian.2`       | `#121722`  | raised surface / input well                   |
| `stroke.hairline`     | `#1E2735`  | 1px structural separators                     |
| `accent.cyan`         | `#22E4FF`  | primary accent, active edges, focus glow      |
| `accent.cyan.dim`     | `#0E7C8C`  | inactive accent, idle telemetry lines         |
| `alert.magenta`       | `#FF2D9B`  | errors, destructive confirms, hot alerts      |
| `track.amber`         | `#FFB020`  | tracking highlights, gesture crosshair, focus |
| `text.primary`        | `#EAF2F7`  | body text on obsidian                         |
| `text.muted`          | `#7C8CA0`  | secondary labels, metadata tags               |
| `ok.mint`             | `#3DF5C4`  | healthy status, verified hashes               |

**Theme B — Industrial Cathode** (rugged; charcoal plate + military amber)

| Token                 | Hex        | Role                                          |
|-----------------------|------------|-----------------------------------------------|
| `plate.charcoal.0`    | `#0C0C0A`  | textured backplate (paired with noise map)    |
| `plate.charcoal.1`    | `#17160F`  | raised riveted panel                          |
| `plate.charcoal.2`    | `#221F16`  | recessed slot                                 |
| `stroke.stencil`      | `#3A3524`  | stencil separators, bracket strokes           |
| `amber.font`          | `#FFC24A`  | primary military-amber typeface color         |
| `amber.font.dim`      | `#8A6A24`  | inactive amber, ghosted labels                |
| `green.radioactive`   | `#9DFF3C`  | monochrome CRT readouts, live meters          |
| `orange.hazard`       | `#FF6A1A`  | hazardous warning banners, over-temp          |
| `text.stencil`        | `#E8D9A8`  | high-legibility stencil body text             |
| `text.stencil.muted`  | `#9A8C63`  | secondary stencil metadata                    |
| `warn.zebra.a`        | `#000000`  | error zebra stripe A                          |
| `warn.zebra.b`        | `#FFB020`  | error zebra stripe B (glowing amber)          |

Themes swap by remapping a single uniform block; all components reference tokens,
never raw hex, so a theme flip is one buffer upload with zero relayout.

### 1.2 The "CRT Glass Glow" compositor filter

The compositor runs a two-stage post pass. Stage 1 is per-surface **Material
Diffusion** (glass); Stage 2 is a full-screen **CRT Glass Glow** applied to
everything *behind* the focused surface, so the active window stays razor-crisp
while the background reads as a warm powered-on display.

All four effects — scanlines, curvature warp, chromatic aberration, bloom — live
in one WGSL fragment shader sampling the composited backbuffer texture `tex` at
normalized `uv`.

**Screen-curvature warp (1.5%).** Bend UVs outward from center so the plane reads
as a subtly convex tube. `k = 0.015` is the 1.5% strength.

```wgsl
fn curve_uv(uv: vec2<f32>) -> vec2<f32> {
    let k: f32 = 0.015;                 // 1.5% barrel
    var c = uv * 2.0 - 1.0;             // center to [-1,1]
    let r2 = dot(c, c);
    c = c * (1.0 + k * r2);             // push edges out with radius^2
    return c * 0.5 + 0.5;              // back to [0,1]
}
```

**Chromatic aberration.** Sample R and B channels along a radial offset that
grows toward the edges (lenses disperse most at the rim), G stays centered.

```wgsl
fn sample_ca(uv: vec2<f32>) -> vec3<f32> {
    let center = vec2<f32>(0.5, 0.5);
    let dir = uv - center;
    let amt = 0.0016 + 0.0032 * dot(dir, dir); // stronger at edges
    let off = dir * amt;
    let r = textureSample(tex, samp, uv + off).r;
    let g = textureSample(tex, samp, uv).g;
    let b = textureSample(tex, samp, uv - off).b;
    return vec3<f32>(r, g, b);
}
```

**Horizontal scanlines (faint).** A sine over the vertical pixel index, kept at
~4% depth so it textures without harming legibility. Line pitch is 2 physical
pixels; multiply density by the display scale so it holds at any DPI.

```wgsl
fn scanline(uv: vec2<f32>, screen_h: f32) -> f32 {
    let line = sin(uv.y * screen_h * 3.14159265); // 1 cycle / 2 px
    return 1.0 - 0.04 * (0.5 + 0.5 * line);        // 4% dip on dark lines
}
```

**Bloom / glass glow.** A cheap 5-tap separable bright-pass on the diffused
buffer, added back so neon strokes and amber readouts halo softly.

```wgsl
@fragment
fn crt_glass_glow(@location(0) uv0: vec2<f32>) -> vec4<f32> {
    let uv = curve_uv(uv0);
    // off-tube pixels render as the bezel void
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        return vec4<f32>(0.02, 0.024, 0.03, 1.0);  // bg.obsidian.0-ish bezel
    }
    var col = sample_ca(uv);                        // chromatic aberration
    // bright-pass bloom (5-tap cross)
    let px = 1.0 / vec2<f32>(u.screen_w, u.screen_h);
    var glow = vec3<f32>(0.0);
    glow += max(col - 0.6, vec3<f32>(0.0));
    glow += max(textureSample(tex, samp, uv + vec2<f32>( px.x, 0.0)).rgb - 0.6, vec3<f32>(0.0));
    glow += max(textureSample(tex, samp, uv + vec2<f32>(-px.x, 0.0)).rgb - 0.6, vec3<f32>(0.0));
    glow += max(textureSample(tex, samp, uv + vec2<f32>(0.0,  px.y)).rgb - 0.6, vec3<f32>(0.0));
    glow += max(textureSample(tex, samp, uv + vec2<f32>(0.0, -px.y)).rgb - 0.6, vec3<f32>(0.0));
    col += glow * 0.35;                              // additive halo
    col *= scanline(uv, u.screen_h);                 // scanlines
    // vignette to seat the tube in its bezel
    let v = 1.0 - 0.25 * dot(uv - 0.5, uv - 0.5) * 4.0;
    col *= v;
    return vec4<f32>(col, 1.0);
}
```

**Material Diffusion (glass) — the per-surface pre-pass.** Before the CRT pass,
each panel is a glass layer: separable Gaussian blur of the backdrop (sigma by
role — 16pt panels, 32pt background windows, 48pt HUD), chroma-adaptive tint
toward the sampled backdrop mean, and the WCAG contrast guarantee that deepens
tint alpha in +0.04 steps until body text clears a 4.5:1 ratio. The focused
surface is exempted from Stage 2 CRT distortion (curvature/aberration = 0 over
its rect) so the thing you are working in is always optically perfect.

**Cost budget.** Whole post chain is one full-screen pass, < 0.4 ms at 4K on a
mid-range GPU. Effects are per-theme scalable: Theme A runs aberration at
`0.0016`, Theme B pushes it to `0.0026` and drops scanline pitch to a chunkier
3px for the heavier industrial feel.

---

## SECTION 2 — The Spatial Infinite Canvas Wireframe

Asymmetrical layout: a rugged left-aligned telemetry bracket runs the full
height; application panels float borderless with sharp 45° corner cuts (never
rounded); a glowing amber crosshair sits at the optical center as the gesture
focus point.

```
╔═╗                                                                              
║T║  OUTRUN // metropolis-terminal                    ⌗ 78%  ▲NET  22:41:07  ▮▮▮
║E║ ┌─────────────────────────────────────────────────────────────────────────┐
║L║ │                                                                          
║E║ │        ╱───────────────────────╲            ╱────────────────────╲       
║M║ │       ╱   TIME-STREAM           ▔╲          ╱  COMM-DECK          ▔╲     
║E║ │      │  ◄══ Mar '26 ═══ NOW ══►  │        │  ▸ Sarah    ▸ Dev-Net  │    
║T║ │      │  [img] [doc] [vec] [bin]  │        │  ✉ 03   ◉ 01   ◈ mic   │    
║R║ │       ╲  45° cut corners, no     ╱         ╲  borderless glass      ╱    
║Y║ │        ╲───────────────────────╱            ╲────────────────────╱      
║ ║ │                                                                          
║B║ │                              ╱▔▔╲                                        
║R║ │                          ────┤ ✛ ├────   ◄ gesture crosshair (amber)     
║A║ │                              ╲▁▁╱             tracks 21-pt hand landmark 
║C║ │                                                                          
║K║ │        ╱──────────────────────────────────────────────────╲            
║E║ │       ╱  ▸ ACTIVE WORKSPACE — Video Editor                  ▔╲          
║T║ │      │   direct 4K cam + audio HAL ring · casts tight shadow  │         
║ ║ │       ╲  focused surface: CRT distortion OFF, optically crisp ╱         
║▮║ │        ╲──────────────────────────────────────────────────╱           
╚═╝ └─────────────────────────────────────────────────────────────────────────┘
    ▸ CONTEXT: scroll=zoom canvas · 3-finger drag=pan · fist=grab · spread=zoom-out
```

**Left telemetry bracket (`TELEMETRY BRACKET`).** Fixed 48pt wide, full height,
`plate.charcoal.1` with a `stroke.stencil` right edge. Vertical stencil letters
label it. Bottom cell `▮` is a live vertical load bar. It never scrolls with the
canvas — it is bolted to the frame like a rugged instrument rail.

**Global status strip.** Top row, 32pt, right-aligned cluster: capability/CPU
`⌗`, battery %, network `▲`, clock, and a 3-cell audio meter `▮▮▮`. Left side
carries the system wordmark in `accent.cyan`.

**Floating application panels.** Borderless, background `bg.obsidian.1` at 82%
through the glass pass. Corners are cut at 45° via a clip-path polygon (a 14pt
chamfer on each corner), never a border-radius. A 1px `accent.cyan` edge lights
only on the focused panel; unfocused panels drop to `stroke.hairline`.

**Time-Stream** sits upper-left of the canvas center; **Comm-Deck** upper-right —
deliberately unequal spacing (the canvas breathes asymmetrically). Both are
ordinary canvas bodies and can be flung, but spawn docked to these anchor zones.

**Gesture crosshair.** A `track.amber` `✛` at optical center with a soft bloom
halo (it is a bright-pass contributor in the CRT shader). It is the reticle the
camera gesture engine drives; when a hand is tracked it leaves a 6-frame amber
motion trail. When no hand is present it dims to `amber.font.dim` and shrinks 20%.

---

## SECTION 3 — Deep Component Specifications

### 3.1 The System Telemetry Monitor

Blocky tactical widget. Fixed 300×184pt. Theme B shown (Industrial Cathode):
`plate.charcoal.1` body, `stroke.stencil` brackets, `green.radioactive` live
meters, `orange.hazard` when any bar crosses threshold. Every value is wrapped in
technical brackets and reported as a percentage or explicit unit.

```
┌─[ SYS.TELEMETRY ]──────────────────────[ LIVE ]─┐
│                                                  │
│  [ WEBCAM.GESTURE ]     NODE ▸ ACTIVE      98%  │
│  ▸device: cam0   route: sys.gesture   21-pt lock │
│  ├████████████████████████████████████░░░┤ conf │
│                                                  │
│  [ MIC.DIRECT ]         PIPE ▸ PASSTHRU    ──   │
│  ▸device: mic0   route: mixer.app    zero-copy   │
│  ├██████████████████░░░░░░░░░░░░░░░░░░░░░░┤ -18dB │
│                                                  │
│  [ GPU.THERMAL ]        CORE ▸ NOMINAL    61°C  │
│  ├███████████████████████████░░░░░░░░░░░░░┤ 61%  │
│  [ GPU.THERMAL ]        HOT  ▸ HAZARD     87°C  │
│  ├████████████████████████████████████▓▓▓┤ 87%  │  ◄ bar turns orange.hazard
│                                                  │
│  [ NPU ]  IDLE·throttled     [ MMIO ] 3 mapped  │
└──[ cap: HW_PASSTHROUGH ✓ ]───────[ slot A ]─────┘
```

Definition notes:
- **Header brackets** `[ SYS.TELEMETRY ]` / `[ LIVE ]` are `stroke.stencil` strokes
  with `amber.font` labels; `[ LIVE ]` pulses `green.radioactive` at 0.5 Hz.
- **Meter bars** are fixed 40-cell `├ ┤` gauges. Fill glyph `█` in
  `green.radioactive`; when value ≥ threshold the exceeding cells switch to `▓`
  in `orange.hazard` and the row's status token flips `NOMINAL → HAZARD`.
- **Passthrough rows** show `device`, `route`, and a mode tag (`zero-copy`,
  `21-pt lock`) pulled straight from the kernel's device registry — this widget is
  the visual face of `sys_hardware_passthrough`. `MMIO 3 mapped` counts live grants.
- **Footer** shows the holding process's capability check `✓` and the active A/B
  root slot, tying the UI to the real kernel state.

### 3.2 The Time-Stream Node (single file block)

How one file appears on the timeline. Fixed 236×132pt card, 45° chamfered
corners, `bg.obsidian.2` plate (Theme A). Carries a monospaced data-matrix tag
row, an abbreviated SHA-256, and a diagnostic bar.

```
   ╱────────────────────────────────────╲
  ╱  ▣ q3_revenue_chart.png         IMG   ╲
 │  ┌─ data.matrix ──────────────────────┐ │
 │  │ kind:img  proj:#mktg  from:Sarah   │ │
 │  │ 14 Mar 26 · 14:22:07 · 1.24 MB     │ │
 │  └────────────────────────────────────┘ │
 │  sha256 ▸ 868d9e65…a1f4bb   [verified✓] │
 │  ├████████████████████████░░░░░░┤ vec 82%│
  ╲  ◈ semantic-indexed   ◉ restore-ctx   ╱
   ╲────────────────────────────────────╱
```

Definition notes:
- **Title row:** filename in `text.primary`, right-tag (`IMG`/`DOC`/`VEC`/`BIN`)
  in `accent.cyan` inside a stencil box.
- **data.matrix block:** monospaced key:value tags the local AI auto-populated —
  `kind`, `proj`, `from`, timestamp, size. Never manually entered.
- **SHA-256 line:** first 8 + last 6 hex of the content hash (`868d9e65…a1f4bb`),
  abbreviated with an ellipsis, followed by `[verified✓]` in `ok.mint` when the
  stored bytes re-hash to the same digest (the CAS integrity check from the
  `cas_vfs` subsystem). A mismatch shows `[CORRUPT]` in `alert.magenta`.
- **Diagnostic bar:** `vec 82%` shows embedding-index progress. While the edge AI
  is still vectorizing (`vector_id = 0`) the bar animates in `track.amber`; once
  indexed it locks solid `accent.cyan` and `semantic-indexed` lights up.
- **Actions:** `◉ restore-ctx` snaps the canvas back to the workspace state
  captured when this file entered the Time-Stream.

---

## SECTION 4 — Hardware-Accelerated Micro-Animations

All timings are wall-clock milliseconds at 120 Hz (values hold at 60 Hz; the
compositor drives them off a time uniform, not frame counts). Curves are given as
`cubic-bezier` for CSS-side components and as the equivalent WebGPU eased `t`.

### 4.1 Window open — "glitch-in"

Instantaneous digital materialization: rapid opacity+scale snap with an
intentional RGB split that resolves as it lands.

```css
@keyframes glitch-in {
  0%   { opacity: 0.90; transform: scale(0.90); filter: none; }
  35%  { opacity: 0.96; transform: scale(0.985)
         translateX(1.5px);                       /* channel tear */
         filter: drop-shadow(2px 0 0 #22E4FF)
                 drop-shadow(-2px 0 0 #FF2D9B); }  /* cyan/magenta split */
  70%  { transform: scale(1.006) translateX(-0.5px); }
  100% { opacity: 1; transform: scale(1.0) translateX(0);
         filter: none; }
}
.window-opening {
  animation: glitch-in 45ms cubic-bezier(0.2, 0.9, 0.1, 1.0) both;
  will-change: opacity, transform, filter;
}
```

- Duration **45 ms**, single shot. The scale runs 90%→100% while opacity runs
  90%→100% (the panel is never fully invisible — it *snaps* in, it doesn't fade).
- The mid-frame `drop-shadow` pair is the deliberate color separation: +X cyan,
  −X magenta, amplitude 2px, fully gone by 100%.
- WebGPU path: a per-window uniform `t01` drives `scale = mix(0.90,1.0,ease(t))`
  and a horizontal `chroma_offset = 2px * (1-t) * pulse(t)` fed to the panel's own
  aberration sampler, so it matches the CRT look exactly.

### 4.2 Error state — hazard zebra flash

The panel edge flashes a diagonal zebra of black / glowing amber at **4 Hz**
(250 ms period, 125 ms per phase).

```css
@keyframes hazard-zebra {
  0%,49%   { border-image: repeating-linear-gradient(45deg,
             #000000 0 8px, #FFB020 8px 16px) 4;
             box-shadow: 0 0 12px #FFB02066; }
  50%,100% { border-image: repeating-linear-gradient(45deg,
             #FFB020 0 8px, #000000 8px 16px) 4;   /* stripes invert */
             box-shadow: 0 0 20px #FFB020AA; }
}
.window-error {
  border: 4px solid transparent;
  animation: hazard-zebra 250ms steps(1, end) infinite; /* 4 Hz, hard toggle */
}
```

- **4 Hz** = 250 ms period; `steps(1,end)` gives the hard mechanical toggle (no
  smooth tween — hazard signage snaps).
- Stripe pitch 8px at 45°; the two phases swap which stripe is black vs
  `warn.zebra.b` amber, reading as motion along the diagonal.
- The `box-shadow` pulse makes the amber "glow" breathe with the toggle. Stops on
  acknowledge; the panel eases border back to `stroke.hairline` over 120 ms.

### 4.3 Close / gesture-fling — matrix dissolve

Flinging a window away (camera fist-throw or 3-finger push) pixelates it into a
stream of horizontal scan-lines in the window's own accent color, which then
race off in the fling direction.

```css
@keyframes matrix-dissolve {
  0%   { opacity: 1;  filter: none;
         clip-path: inset(0 0 0 0); }
  30%  { filter: contrast(1.4) brightness(1.2)
                 url(#lineShatter);          /* SVG displacement -> H-lines */ }
  100% { opacity: 0;
         transform: translateX(var(--fling-x)) skewX(8deg) scaleY(0.4);
         filter: blur(1px) url(#lineShatter);
         clip-path: inset(0 0 0 60%); }       /* trailing edge tears away   */
}
.window-flinging {
  --fling-x: 480px;              /* set to the gesture velocity vector      */
  animation: matrix-dissolve 220ms cubic-bezier(0.4, 0.0, 0.9, 0.3) forwards;
}
```

WebGPU implementation (the real path; CSS above is the fallback for DOM apps):

```
1. Snapshot the window into an offscreen texture T.
2. Fragment shader over T, param t01:
     • quantize uv.y into N horizontal bands (N = 48 * (1 - t)) -> chunky lines
     • per-band horizontal offset = hash(band) * t * fling_dir * 40px
     • per-band alpha = step(t, hash(band))  -> bands wink out staggered
     • tint surviving bands toward the window's accent (accent.cyan or the
       app's declared accent) and add to the bloom bright-pass so they streak
3. Bands accelerate along fling_dir; last band gone at t=1 (220 ms).
```

- Duration **220 ms**. The window shears into horizontal matrix lines colored by
  its primary accent, each line staggered so it reads as a dissolve into a data
  stream rather than a uniform fade.
- `--fling-x` (and a `--fling-y`) are driven by the actual gesture velocity from
  the 21-point hand tracker, so a hard throw scatters the lines farther and
  faster than a gentle push.

---

## Cross-reference to running code

- **§3.1 telemetry / passthrough count** reflects `sys_hardware_passthrough` in
  the bare-metal kernel (`metal/kernel/kernel64.c`) — the widget's "MMIO N mapped"
  and "cap: HW_PASSTHROUGH ✓" are exactly the kernel's grant path, now backed by
  real 4-level page tables (see `docs/metal-passthrough-boot.log`).
- **§3.2 SHA / [verified✓]** reflects the CAS integrity guarantee in
  `subsystems/cas_vfs.rs` (content re-hash on read).
- **§4** motion parameters feed the same bloom bright-pass and aberration sampler
  defined in Section 1's CRT shader, so widgets and window motion share one
  optical model rather than bolting on separate effects.
