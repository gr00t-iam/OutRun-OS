# Outrun OS v0.7 — Phase 1: CAS storage layer + polyglot boot image

Two things land together: a persistent content-addressable store on top of the
virtio-blk primitives, and the first genuinely unified C/C++/Rust/asm boot image.

## Content-Addressable Storage (CAS) on virtio-blk
A block's address IS the hash of its content; identical content is stored once.

On-disk layout (persisted):
- block 0        superblock ("ORUNCAS1", geometry, counters)
- bitmap_start.. allocation bitmap (1 bit/block)
- index_start..  open-addressed hash index {content-hash -> block, len}
- data_start..   content blocks

Operations:
- cas_format / cas_mount — lay out or re-open a volume; the superblock and
  bitmap persist and are re-read on the next boot.
- cas_put(data,len) -> hash — hashes the content (via Rust), looks it up; on a
  hit it DEDUPLICATES (no allocation, no write); on a miss it allocates a block,
  writes it, and inserts the index entry. All metadata flushed to disk.
- cas_get(hash,out,max) -> len — resolves hash -> block and reads it back.

Proof (docs/cas-boot.log), two boots against the same disk image:
- BOOT 1 (fresh): formats 8192 blocks; stores two distinct blobs at blocks 19
  and 20; the third put (identical content) DEDUPs to block 19. Blocks used +2.
- BOOT 2 (same disk): `mounted existing volume: 21/8192 blocks used, 3 puts,
  1 dedup hits` — the superblock and counters survived the reboot. Now ALL three
  puts dedup to the blocks written in boot 1 (blocks used +0), and cas_get reads
  the original content back off the disk.
- On the host, sector 0 shows the `ORUNCAS1` magic and blocks 19/20 hold the
  literal stored strings — durable outside the VM.

## Unified polyglot boot image (C + C++ + Rust + assembly)
The staged polyglot objects are now linked into the actual kernel:
- rust/cap_engine.rs (no_core Rust, x86_64-unknown-none) provides:
  - rust_cas_hash() — the FNV-1a content hash the CAS layer uses for every put.
  - rust_cap_check() — now the ACTUAL gate inside sys_hardware_passthrough; the
    ring-3 capability grant/deny is decided by Rust code (still grants stream-app,
    denies sketchy-app in the boot trace).
- cpp/ipc_ring.cpp (freestanding C++) — the zero-copy SPSC ring; a boot self-test
  pushes/pops through it ("polyglot-ipc"), proving the C++ TU is live.
The Makefile now compiles the Rust object (RUSTC_BOOTSTRAP no_core build) and the
freestanding C++ object and links both into outrun-kernel.elf alongside the C and
NASM objects.

## Notes / scope
- The destructive `disk` write test was removed from the boot path (it clobbered
  sector 0); it remains as a manual shell command for scratch disks.
- CAS blocks are 512 bytes; the index is a fixed 512-slot open-addressed table
  (fine for the demo, grows later). Single outstanding I/O, polling completion.
