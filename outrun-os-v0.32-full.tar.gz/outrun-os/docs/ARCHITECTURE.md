# Outrun OS Architecture

## The layer model

The system stacks three layers. At the bottom, a memory-safe Rust microkernel
owns exactly four things: virtual memory, scheduling, IPC endpoint routing, and
the capability table. Everything else — file systems, network stacks, and every
device driver — runs as an ordinary supervised user-space process. Above that
sits the capability-based mediation layer, which exists only at mapping setup
time and vanishes from the data path afterward. On top, the unified application
layer hosts Nexus Marketplace apps, sideloaded open-source apps, WASM runtimes,
and Linux/Android micro-VMs, all on identical sandbox infrastructure.

## Grant-once, then unrestricted

The single most important architectural decision, and the one this prototype
exists to prove: kernel mediation happens at *setup*, never at *use*. When an
application requests the camera, the kernel mints a capability (an unforgeable
record living only inside the kernel's table), publishes its generation number
into the device region header, and maps the region into the app's address space.
From that moment the app's access is direct and unrestricted in exactly the way
the charter demands — polling for a new frame costs one assembly MOV, reading it
costs a seqlock over shared memory, and no syscall, copy, or prompt ever appears
per-frame. The measured result in `demo-run.log` is ~188 fps sustained with the
consumer doing zero kernel transitions on the hot path.

## Capability handles

A handle is a (slot, generation) pair. It is not a cryptographic token passed
around userspace — that was an early design error this revision removes, because
bearer tokens can be exfiltrated and replayed. Instead the authoritative record
never leaves the kernel; the pair userspace holds is only meaningful because the
kernel wrote the matching generation into the region header it controls. Forging
a pair is useless: the kernel table is the source of truth, and the mapping
itself was established by the kernel. This mirrors the seL4/Zircon model of
kernel-object-referenced capabilities rather than data-valued ones.

## Revocation by generation

Revoking never requires the holder's cooperation. The kernel bumps the holder's
generation slot in the region header (one atomic 8-byte store), and the holder's
next `outrun_cap_check` — one assembly compare — returns dead. In the full
system the kernel additionally unmaps the pages, making revocation enforced
rather than merely observed; the prototype demonstrates the observation path,
and the demo shows the app exiting on its next poll with no signal delivered.

## Multi-consumer zero-copy

The camera region is a latest-frame broadcast buffer: four seqlock-protected
slots plus a monotonic `latest` counter. The producer writes each frame exactly
once; any number of readers consume it in place with independent cursors. The
demo runs two simultaneous consumers (the stream app and the gesture engine)
against one producer with no duplication and no coordination between readers.
Latest-frame semantics are the correct choice for sensor streams — a slow
consumer skips frames rather than exerting backpressure on the device.

## The gesture pipeline privacy boundary

The spatial gesture engine is a system service holding its own capability to raw
pixels. What it forwards to the compositor are derived landmark and gesture
events, never frames. Applications that want raw camera pixels request their own
grant. This closes the hole flagged in review — an always-on gesture loop must
not become a covert channel that leaks the camera to everything on screen.

## Crash isolation

Drivers are ordinary processes, so a driver bug is an ordinary process death.
The demo injects a null MMIO dereference into the live camera driver; it dies
with SIGSEGV, the supervisor restarts it 18 ms later, the replacement resumes
frame numbering by reading `latest` from the region, and the worst stall any
consumer observed across the entire event was 32.4 ms. On a monolithic kernel
the same bug is a kernel panic.

## Atomic A/B updates

Two content-addressed root slots, active and passive. Updates stage into the
passive slot and are verified against the manifest's content hash before
anything is touched; a corrupted download is rejected and wiped with the active
slot never at risk, which the demo exercises deliberately. On success the active
pointer flips. The scope is stated honestly: the flip is reboot-free for
userspace (running apps keep old mappings, new launches get the new libraries),
while kernel-image changes take a fast soft-reboot with automatic rollback — a
new syscall ABI cannot be hot-swapped underneath live processes, and any design
claiming otherwise is claiming memory corruption.

## Mapping simulation to bare metal

The prototype substitutes POSIX process isolation for hardware address-space
isolation, `/dev/shm` files for kernel-established MMIO mappings, and a parent
supervisor for the kernel's process manager. Every protocol — the seqlock frame
format, the generation-slot revocation scheme, the capability table semantics,
the A/B verify-then-flip sequence — transfers unchanged to bare metal; only the
mechanism that establishes mappings (page tables and IOMMU instead of mmap)
changes. The roadmap document sequences that transition.
