# Outrun OS v0.25 — the Metropolis-Terminal Spatial Canvas

Pivots up-stack. The compositor was a fixed animation; it is now a real
interactive spatial canvas — the blueprint's interface promise, running on the
hardened kernel.

## Windows live in a world, not on a screen
- A camera (pan + zoom) in 16.16 fixed point projects world space to the screen:
  w2sx/w2sy/wsc, with FXDIV for the inverse. No FPU is used anywhere (the kernel
  is built -mno-sse -msoft-float), so the whole canvas is integer math.
- The grid is world-anchored and its spacing follows the zoom, so panning and
  zooming move through a continuous space rather than scrolling a bitmap. A world
  origin marker makes this visible.
- Frustum culling + level-of-detail: off-screen windows are skipped; windows that
  shrink below ~10 px collapse to a coloured tick instead of a full panel.
- Zoom is clamped to 12.5%..400%.

## Interaction: keyboard-first, three input modes' worth of affordances
- WASD pans (pan distance scales inversely with zoom, so it feels constant).
- Q/E zoom out/in, F = zoom-to-fit, TAB cycles focus (and centres the camera on
  it), X/ESC exits.
- All input arrives through the existing PS/2 IRQ ring buffer.

## The Accelerator HUD (`/`)
- Opens a command bar with a live-filtered command list, a caret, and a
  highlighted first match. ENTER runs the top match, ESC closes, backspace edits.
- Commands: zoom fit / zoom in / zoom out / center canvas / tile windows and
  focus <window> for each of the five panels.
- Case-insensitive prefix filtering: typing "foc" narrows the list to exactly the
  five focus commands (see docs/spatial-canvas.png).

## Volumetric depth + Context Ribbon
- The focused window is drawn last, raised with a soft offset shadow and cyan
  corner brackets; background windows keep the glass-diffusion treatment.
- A context ribbon at the bottom changes with the input mode:
  "WASD PAN  Q/E ZOOM  TAB FOCUS  F FIT  / ACCELERATOR  X EXIT" becomes
  "TYPE FILTER  ENTER RUN  ESC CLOSE" while the HUD is open. It also shows the
  live zoom percentage and the focused window's name.

## Verified
A scripted demo runs at boot and drives the canvas by injecting keystrokes ONE
AT A TIME, at typing pace, into the real PS/2 ring buffer — the same path a
physical key takes (not a back door into the state machine). The script pans,
zooms, moves focus, opens the HUD, types and executes "zoom fit", then reopens
the HUD and types "foc". Result:

    [canvas ] 300 frames | camera world (-30,0) zoom 88% | focus 'COMM-DECK' | hud open

The camera really moved in world space, zoom-to-fit computed an 88% fit, TAB
moved focus, and the HUD is open and filtering. Screenshot: docs/spatial-canvas.png.

`canvas` in the shell runs it interactively for a real keyboard.

## Honest scope
- Keyboard only so far: no mouse/trackpad or camera-gesture input yet (there is
  no PS/2 mouse driver). The blueprint's three-input-modality story is one third
  done; the camera/transform layer is the part all three would share.
- The five panels are still rendered demo content, not live application surfaces.
- The earlier fixed animation (`gfx`) is retained and still screenshot-verified.

## Status
All prior suites remain green on top of this: 19/19 validation, 21/21 invariants,
10/10 stress, 8/8 fuzz, 2/2 iommu, 11/11 capdma, ring-3 userspace driver TX
completed, plus CAS, DHCP, compositor, ring-3 demos and the shell. Zero exceptions.
