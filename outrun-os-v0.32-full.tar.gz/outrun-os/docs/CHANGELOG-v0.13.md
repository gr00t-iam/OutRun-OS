# Outrun OS v0.13 — Phase 4: framebuffer graphics + Metropolis-Terminal compositor

The kernel now drives a real linear framebuffer and renders the Metropolis-
Terminal visual language to actual pixels, with a capability-gated zero-copy
framebuffer mapping for a ring-3 graphics manager.

## Framebuffer bring-up
- Added a Multiboot2 framebuffer request tag to the header; GRUB sets a
  1024x768x32 linear framebuffer (VBE under BIOS, GOP under UEFI) and passes it
  in the framebuffer info tag, which the kernel parses (addr/pitch/w/h/bpp).
- Maps the framebuffer (phys 0xFD000000 under QEMU stdvga) into kernel space and
  allocates a RAM backbuffer: all rendering is DOUBLE-BUFFERED (render to the
  backbuffer, then flip to the hardware framebuffer).

## Graphics engine (integer / fixed-point — no SSE/FPU)
- Pixel plot, rectangle, lines, and an alpha-blend primitive (glass diffusion).
- Chamfered glass panels: two opposite 45-degree cut corners, translucent
  gradient fill, an accent header band, and a glowing neon edge.
- Telemetry meter bars, an infinite-canvas grid, a left telemetry bracket, an
  amber gesture crosshair with glow, and horizontal scanlines (every other row
  darkened) — the CRT look, in software.
- Window physics in 16.16 fixed-point: spring toward targets (zeta 0.82) plus
  mass-weighted AABB collision separation, settled over 480 steps so the panels
  push each other apart into a non-overlapping layout instead of stacking.

## sys_map_framebuffer (zero-copy, capability-gated)
- New PCAP_FRAMEBUFFER capability and syscall #10: maps the linear framebuffer
  straight into a process's address space (user vaddr 0x550000000000) so a
  ring-3 graphics manager can write pixels directly — no copy.
- Proven end-to-end: the CAS-loaded ring-3 process (granted CAP_FRAMEBUFFER)
  maps 3 MiB of framebuffer and draws a marker directly onto the display, on top
  of the kernel compositor; processes without the capability are cleanly denied.

## Proof (docs/compositor-render.png)
An actual QEMU screendump of the rendered display: obsidian canvas with grid,
five chamfered glass panels with cyan/magenta/amber neon edges settled by the
physics loop, telemetry bracket, gesture crosshair, scanlines — plus the amber
marker square drawn by the ring-3 graphics manager (top-right). Verified by
pixel read-back on the serial console and by analyzing the screenshot.

## Scope / next (Phase 4 cont. / Phase 5)
- Software renderer with a static settled frame; an animated compositor loop and
  a text/font layer are natural extensions. The ring-3 wm draws a marker today;
  a full ring-3 compositor using the mapped framebuffer is the follow-on, leading
  into Phase 5 (Time-Stream workspace + production validation).
