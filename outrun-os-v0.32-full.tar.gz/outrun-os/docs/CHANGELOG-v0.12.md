# Outrun OS v0.12 — Phase 3 complete: zero-copy IP/UDP packet router

Builds on the async RX path (v0.11) with a freestanding IP/UDP router that parses
frames in place and routes datagrams to bound execution slots by port — proven
with a real DHCP exchange against QEMU's SLIRP.

## Zero-copy IP/UDP router
- Parses Ethernet -> IPv4 -> UDP entirely IN PLACE: pointers into the RX buffer,
  no memcpy. Validates IPv4 version, walks the IHL, checks protocol 17 (UDP),
  and extracts src/dst ports, length, and a payload pointer.
- Port filter array (NUDP slots): udp_bind(port, tid) registers a UDP dst port
  and the execution slot to route matches to.
- On a match, the router hands the payload POINTER to the owning slot and wakes
  that thread — the datagram is delivered without ever being copied.
- Runs in the RX bottom half (net_dispatch): ARP frames go to the ARP waiter,
  IPv4 frames go to the UDP router.

## Proof (docs/udp-router-boot.log) — real DHCP round-trip
- `[dhcpd] bound UDP port 68 -> execution slot 0`
- The kernel builds a valid DHCPDISCOVER (Ethernet broadcast / IPv4 with a
  computed header checksum / UDP 68->67 / BOOTP with magic cookie + options) and
  transmits it, then parks on the port-68 slot.
- SLIRP's DHCP server replies; the RX IRQ drives the router, which matches dst
  port 68 and routes the payload pointer to slot 0, waking dhcpd.
- `[dhcpd] router delivered 548-byte UDP payload (zero-copy pointer)`
- `[dhcpd] DHCP OFFER: offered IP 10.0.2.15, server 10.0.2.2` — parsed in place
  from the routed pointer (yiaddr + option 53/54).

Phase 3 items 1 (async IRQ routing + sys_wait_event) and 2 (zero-copy IP/UDP
router) are both demonstrated end-to-end. The full boot (CAS, scheduler, VFS,
exec-from-CAS, ARP + DHCP) is stable and reaches the shell; virtio-blk and
virtio-net share IRQ 11 without conflict.

## Helpers added
- ip_checksum() (one's-complement IPv4 header checksum).
- udp_bind / net_wait_slot (park a thread on a bound port).
- A DHCP client builder + in-place option walker.

## Scope / next (Phase 4)
- Single outstanding round-trip per demo; RX buffer recycling and a TX
  completion reclaim loop are natural hardening steps. Phase 4 is the graphics
  server: VBE/GOP framebuffer + sys_map_framebuffer + the Metropolis-Terminal
  compositor on bare metal.
