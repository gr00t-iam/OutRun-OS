# Outrun OS v0.4 — what changed

## Kernel 0.4.0-metal — genuine ring-3 user mode
The capability passthrough is now a REAL trap from an unprivileged process.

- New `metal/boot/usermode.asm`:
  - `syscall_entry` — SYSCALL lands here in ring 0, swaps to a dedicated kernel
    stack, marshals args, calls the C dispatcher, and SYSRETs back to ring 3.
  - `enter_user_mode` — builds an iretq frame and drops to ring 3 for the first
    time, after saving a kernel resume point.
  - `resume_kernel` — longjmp back into kernel_main from SYS_EXIT.
  - `user_blob` — a self-contained, position-independent ring-3 program that
    reaches the kernel ONLY through `syscall`.
- `metal/kernel/kernel64.c`:
  - `wrmsr`/`rdmsr`; a 64-bit GDT with user code/data segments + a TSS (rsp0 for
    ring3->ring0 traps); `usermode_init()` arms EFER.SCE, STAR, LSTAR, SFMASK.
  - `syscall_dispatch()` implementing SYS_WRITE / SYS_HW_PASSTHROUGH /
    SYS_EXIT / SYS_WRITEHEX.
  - `run_ring3()` maps the user program + stack USER-accessible and enters ring 3.
- Proof (QEMU, BIOS + UEFI, see docs/ring3-boot.log): stream-app (caps 0x3)
  drops to ring 3, issues a SYSCALL, the capability bitset is checked inside the
  trap, the device is GRANTED (mapped at 0x4000c0000000), SYSRET carries the
  result back, SYS_EXIT returns to the kernel. sketchy-app (caps 0x20) runs the
  same SYSCALL and is DENIED (-2). One privilege boundary, two outcomes, decided
  in the trap.

## Compositor prototype — compositor/outrun-compositor.html
A running single-file compositor for the Metropolis-Terminal blueprint:
- Offscreen 2D scene: infinite grid, physics windows (spring k=220, zeta=0.82,
  mass-weighted collision separation), telemetry monitor, Time-Stream node,
  Comm-Deck, video editor, and the amber gesture crosshair with a motion trail.
- CRT-Glass-Glow post pass with three backends tried in order: WebGPU (WGSL) ->
  WebGL2 (GLSL) -> raw Canvas2D. Same shader math in each: 1.5% barrel curvature,
  radial chromatic aberration, ~4% scanlines, 5-tap bloom bright-pass, vignette.
- Micro-animations from the spec: 45ms glitch-in (cyan/magenta split), 4Hz hazard
  zebra error border, 220ms matrix-line dissolve on fling.
- Accelerator HUD (Ctrl/Cmd+K: new / error / fling / theme / resize), A/B theme
  toggle, drag-to-fling physics. The active renderer + theme are shown top-right.
