# Outrun OS v0.14 — Phase 4 complete: animated compositor + text layer

Turns the static Metropolis-Terminal render into a live animation loop and adds a
bitmap font, so panels carry real titles and the desktop assembles itself on screen.

## Text / font layer
- Embedded 8x8 bitmap font (font8x8 subset, ASCII 0x20-0x5F). draw_char / draw_str
  render directly into the backbuffer.
- The compositor now labels everything: an "OUTRUN // METROPOLIS-TERMINAL"
  wordmark and per-panel titles (TIME-STREAM, COMM-DECK, SYS.TELEMETRY,
  TIME-NODE, VIDEO-EDITOR).

## Animated compositor loop
- Persistent window state stepped once per frame: spring toward targets
  (zeta 0.82) plus mass-weighted AABB collision, so the panels start clustered
  in the center and spring/scatter out into a settled, non-overlapping layout.
- Glitch-in reveal: cyan/magenta chromatic ghost edges on the panels that fade
  out over the first 16 frames.
- An amber gesture crosshair that orbits, and the scanline filter, every frame.
- cmd_gfx renders 150 double-buffered frames paced off the 100 Hz PIT (~20 ms
  each), flipping each to the hardware framebuffer, then leaves the settled frame.

## Proof (docs/)
- compositor-v0.14.png — the settled desktop: obsidian canvas, five labeled
  chamfered glass panels with neon edges, telemetry, crosshair, scanlines, and
  the ring-3 graphics-manager marker (top-right).
- compositor-animation.png — early frame vs settled frame side by side;
  ~90,000 pixels change between them, captured from two live screendumps, which
  is the animation running.
- Text verified by sampling (wordmark + subtitle pixels present); the system
  still reaches the shell after the animation, and the CAS-loaded ring-3 process
  still maps the framebuffer and draws its marker.

## Scope / next
- Software renderer at 1024x768x32, full-screen redraw per frame. Phase 4's
  visual identity is now complete on bare metal; next is Phase 5 (the Time-Stream
  workspace + Comm-Deck) and production hardening (ELF bounds-checks, a
  capability audit across syscalls, CAS round-trip tests, a dd-able install ISO).
