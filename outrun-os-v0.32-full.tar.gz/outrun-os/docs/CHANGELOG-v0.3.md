# Outrun OS v0.3 — what changed

## Kernel 0.3.0-metal — capability dispatcher fused into the booting kernel
The userspace capability prototype's mock address spaces are gone. The bare-metal
kernel now runs REAL x86_64 4-level paging:

- `map_page()` / `translate()` — genuine PML4→PDPT→PD→PT walks installing 4 KiB PTEs
- per-process private PML4 via `create_address_space()` (shares the kernel's low
  identity map so kernel code/stack/IDT stay mapped across a CR3 switch)
- `sys_hardware_passthrough(proc, io_addr)` — two capability-bitset gates; on pass
  it installs real PTEs mapping the device's physical MMIO into the process and
  returns the vaddr; on fail it returns a negative code with nothing mapped
- boot-time + interactive `passthrough` demo: switches CR3 into the authorized
  process and reads a device sentinel THROUGH its own virtual mapping (the MMU
  resolves 0x400040000000 → 0x1000000 → 0xCAFEBABE), then shows the unauthorized
  process has no such mapping. Verified booting in QEMU under BIOS and OVMF.

## Docs
- docs/VISUAL-BLUEPRINT.md — original Metropolis-Terminal visual language:
  dual-theme hex palettes, WGSL CRT-glass-glow shader (1.5% curvature, chromatic
  aberration, 4% scanlines, bloom), asymmetrical infinite-canvas wireframe,
  telemetry + time-stream component mockups, and micro-animation timings
  (45ms glitch-in, 4Hz hazard zebra, 220ms matrix dissolve).
- docs/metal-passthrough-boot.log — captured QEMU boot proving the paging path.
