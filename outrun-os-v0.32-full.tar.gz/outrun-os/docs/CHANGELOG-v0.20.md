# Outrun OS v0.20 — syscall argument fuzzing + user-pointer hardening

Fuzzes the syscall boundary with adversarial arguments and fixes the real
vulnerabilities it surfaces: several syscalls were dereferencing ring-3-supplied
pointers with no validation.

## Vulnerability found + fixed (user-pointer validation)
Before this change, SYS_WRITE, SYS_OPEN, SYS_READ and SYS_WRITE_FILE trusted the
pointer/length a ring-3 caller passed. A hostile pointer could fault the kernel
or — worse — make it read or WRITE kernel memory (e.g. SYS_READ with a kernel
buffer address would land file data inside the kernel). Now:
- access_ok(cr3, ptr, len, need_write) validates that a range lies wholly inside
  user space (USER_VMIN..USER_VMAX, no overflow) and every page is present+USER
  (+writable when required), checked against the process's own page tables.
- copy_user_str(cr3, uptr, kbuf, max) copies a NUL-terminated string from user
  space with per-page validation.
- SYS_WRITE and SYS_OPEN now copy the string through copy_user_str; SYS_READ and
  SYS_WRITE_FILE validate the [buf,buf+len) range (length capped at 64 KiB) with
  access_ok. Any bad pointer returns EFAULT (-14) instead of faulting the kernel.

## Fuzzing suite (`fuzz` command) — 8/8
Targeted (the exact holes, now closed):
- SYS_OPEN with a valid user name pointer succeeds; with a kernel address it's
  rejected (EFAULT).
- SYS_WRITE with a kernel-address or unmapped pointer is rejected (no kernel leak).
- SYS_READ into a kernel address is rejected (no kernel write); into a valid user
  buffer it succeeds.
Randomized:
- 20000 calls across all syscall numbers x an adversarial argument pool (0, 1,
  device/fb kernel windows, kernel addresses, USER_VMIN/VMAX edges, ~0, huge
  lengths, valid + unmapped user pages), with rotating capability sets. Result:
  ~13.7k rejected, ~6.3k handled, and the KERNEL NEVER FAULTED.
Post-fuzz integrity:
- Kernel still has zero writable+executable pages; fuzz-process isolation intact.

The fuzzer runs each call in the fuzz process's own address space, so valid
pointers resolve and hostile ones are rejected exactly as in a real ring-3
syscall.

## Note
One production-validation check was updated: it previously "opened" a file using
a kernel string literal as the name; the hardened SYS_OPEN now correctly rejects
that kernel pointer, so the check asserts the capability gate is passed rather
than a successful open.

## Proof (docs/fuzz-boot.log)
Full boot green: 19/19 validation, 21/21 invariants, 10/10 stress, 8/8 fuzz,
DHCP, animated compositor, ring-3 (guarded stacks, register preservation), shell.
Verified on BIOS ISO and the NVMe/UEFI install image.

## Next
Remaining wishlist item: fold a periodic descriptor-table integrity sweep into
the scheduler tick (continuous, rather than on-demand, corruption detection).
