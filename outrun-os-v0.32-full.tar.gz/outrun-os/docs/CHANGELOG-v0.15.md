# Outrun OS v0.15 — Phase 5a: the Time-Stream Engine

An append-only chronological event substrate with a background vector indexer and
terminal query — files, messages, and system activity on one searchable timeline
instead of nested folders.

## Event substrate
- struct ts_event: monotonic seq + tick timestamp, type (FILE / COMM / SYS),
  source, text, and a 64-dim feature-hashed vector.
- ts_emit() enqueues events; safe to call from anywhere, before the indexer runs.

## Hooks (real activity, automatically captured)
- File-write hook inside vfs_write_file: every VFS write emits a FILE event. The
  timeline shows the actual writes from the storage demos (motd, readme, the
  copy-on-write rewrite, the deduped copy) with no manual logging.
- Comm-Deck messages (Sarah / DevTeam / Ops) and system events (netd DHCP, the
  scheduler's worker run) are emitted as COMM / SYS events.

## Background indexer (uses the Phase 2 scheduler)
- A `timestreamd` kernel thread drains the event queue and parses each event into
  its vector: words are lowercased, tokenized, and feature-hashed (FNV) into the
  64-dim bag-of-words vector. Asynchronous substrate, real background thread.

## Local vector query (terminal)
- ts_query() vectorizes the query the same way and ranks every indexed event by
  vector dot-product, returning the top matches. Demonstrated:
  - "the Q3 chart Sarah sent"  -> COMM Sarah: Q3 revenue chart deck (top)
  - "scheduler patch"          -> COMM DevTeam: microkernel scheduler patch
  - "dhcp gateway address"     -> Ops gateway/DHCP + netd DHCP offer
- `stream` shell command reprints the timeline and runs a query on demand.

## Proof (docs/timestream-boot.log)
The chronological timeline of 9 events (4 real file writes + 3 comm + 2 sys),
all vector-indexed by the background thread, and the three ranked queries. Full
boot (CAS, scheduler, VFS, net, DHCP router, compositor, ring-3) is unchanged and
reaches the shell.

## Scope / next (Phase 5b)
- In-memory index (64 events, 64-dim); persistence to CAS and larger indices are
  natural extensions. Next is production hardening: strict ELF segment
  bounds-checking, a capability audit across every syscall entry point, an
  automated CAS round-trip integrity suite, and a dd-able install ISO for NVMe.
