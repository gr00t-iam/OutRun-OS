# Outrun OS v0.24 — the ring-3 userspace device driver

The architectural arc closes. An unprivileged ring-3 process is handed the real
NIC and drives it end to end: the kernel's involvement stops at the capability
check, and the device is hardware-confined to that process's memory while it
does real DMA. Direct hardware access with no ability to corrupt the system.

## What the ring-3 driver does (user/init.c, role 1)
Entirely at ring 3, through syscalls only:
1. sys_hardware_passthrough — the capability gate (CAP_HW_PASSTHROUGH +
   CAP_NETWORK); on success the NIC's MMIO registers are mapped into the
   process AND the device is placed in the process's IOMMU domain.
2. sys_dma_alloc — allocates physically contiguous DMA memory, maps it into the
   process, and adds it LIVE to the process's IOMMU domain.
3. Brings the device up from scratch: reset -> ACK/DRIVER -> feature negotiation
   (VERSION_1 + ACCESS_PLATFORM) -> FEATURES_OK.
4. Builds the TX virtqueue (descriptor table, avail ring, used ring) inside its
   OWN DMA pages, points the device's queue registers at those physical
   addresses, enables the queue, sets DRIVER_OK.
5. Writes a frame into its own page, publishes a descriptor, kicks the notify
   register, and polls the used ring.

Result, on real (emulated) hardware:
    [drv:r3] NIC registers mapped into this process at vaddr 0000400480000000
    [drv:r3] own DMA memory: vaddr 0000520000000000 -> phys 00000000010cd000
    [drv:r3] negotiated features, FEATURES_OK accepted by device
    [drv:r3] TX virtqueue live in our own pages; DRIVER_OK set
    [drv:r3] *** TX COMPLETED BY HARDWARE *** used.idx=1
The NIC read the descriptor and the frame out of the process's memory by DMA —
no kernel driver in the data path — while confined to its owner's IOMMU domain.

## New kernel support
- SYS_DMA_ALLOC (11): capability-gated (CAP_HW_PASSTHROUGH), physically
  contiguous, zeroed, mapped USER|WRITE|NX into a per-process DMA window
  (0x520000000000), returns the IOVA/physical address through a validated user
  pointer. Bounded to 64 pages.
- SYS_ROLE (12): lets one ELF serve as both the demo app and the driver.
- iommu_domain_add_page(): LIVE domain update, so memory allocated after a grant
  joins the device's domain (exercised by the driver: it allocates DMA memory
  after passthrough and the device can reach it).
- SYS_DEV_OFFSET kinds 6..10 expose the NIC's real virtio layout (common /
  notify / ISR / device-config offsets + notify multiplier) so a ring-3 driver
  can locate the register structures inside its own MMIO mapping. (These come
  from virtionet_probe; the old pci_probe_virtio path was dead code.)
- kdev entries carry their PCI source-id; kproc carries role + a DMA bump.

## Notes
- A device reset from ring 3 also clears QEMU's "broken" virtio state, so the
  driver recovers the NIC that `capdma` deliberately faulted earlier in the boot.
- Verified both WITH an IOMMU (device confined to the driver's domain) and
  WITHOUT one (driver still works, simply unconfined) — the driver does not
  depend on the IOMMU being present.

## Honest scope
- TX only; the driver does not set up the RX queue or handle interrupts (it
  polls the used ring). It is a demonstration driver, not a complete NIC stack.
- The in-kernel NIC driver still does not formally relinquish the device on
  grant; the ring-3 driver's device reset is what effects the handoff. A real
  handoff protocol would quiesce the kernel driver first.
- VT-x remains unavailable in this environment (no KVM, TCG does not emulate
  VMXON) and is reported honestly.

## Verified
- q35 + intel-iommu: 19/19 validation, 21/21 invariants, 10/10 stress, 8/8 fuzz,
  2/2 iommu, 11/11 capdma, ring-3 driver TX COMPLETED, plus CAS + DHCP,
  compositor, ring-3 demos, shell. Zero exceptions.
- REGRESSION (no IOMMU): all suites green, ring-3 driver TX still completes.
