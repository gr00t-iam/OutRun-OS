# Outrun OS v0.18 — stress hardening: W^X/NX enforcement + fault injection + TLB/CR3 stress

Pushes invariant coverage from isolation into enforcement and stress: real NX +
W^X across kernel and user, hardware-trap-verified, plus fault injection and
TLB/CR3 stress under preemption. (Uniprocessor: cross-core TLB shootdowns/IPIs
do not apply; single-core equivalents are exercised instead.)

## New hardening (not just tests)
- NX enabled (EFER.NXE) + PTE_NX; CR0.WP enabled so ring 0 respects read-only
  pages (kernel code is now immutable).
- W^X enforced everywhere:
  - Kernel: the identity map is remapped so [_stext,_etext) is R+X and every
    other page (data, stacks, page tables, heap) is RW+NX. The 2 MiB huge page
    covering the kernel image is split to 4 KiB for exact code/data separation.
  - User: the ELF loader marks data/rodata/stack NX and code R+X, and REJECTS
    any writable+executable segment.
  - Device MMIO and the framebuffer (kernel and ring-3 mappings) are now NX —
    this fixed 8 kernel pages that were writable+executable.

## Stress & enforcement suite (`stress` command) — 8/8 passing
- W^X audit: scans every leaf page in an address space; kernel AND user report
  ZERO writable+executable pages (1031 kernel pages scanned, 0 W+X).
- NX poisoning: executing a data page traps (#PF) — caught by a recoverable
  fault hook, confirming NX fires in hardware.
- Write-protect: writing to R+X kernel code traps (#PF) — code is immutable.
- TLB staleness: after remapping a vaddr to a new frame + invlpg, the read sees
  the NEW frame — no stale TLB entry survives.
- CR3 churn under preemption: 20000 address-space switches with the timer
  preempting throughout keep the two spaces perfectly isolated.
- Page-table auditor: detects a flipped reserved bit in a live PTE (bit-flip /
  corruption detection).
- Allocator fault injection: forced frame exhaustion returns failure cleanly,
  no panic or corruption.

## Proof (docs/)
- stress-boot.log — the 8/8 stress run + W^X enforcement line.
- wx-compositor.png — the compositor still renders correctly through the now-NX
  framebuffer mapping.
- Full boot remains green: 19/19 validation, 21/21 invariants, 8/8 stress, DHCP,
  animated compositor, ring-3 (register preservation + VFS + passthrough), shell.

## Honest scope
Single core, so no true cross-core shootdowns. NX/W^X/WP are enforced and
hardware-verified; the auditor catches injected corruption but there is no ECC.
This is the hardened, race-audited base to build the next layer on.
