# Outrun OS Roadmap — from simulation to metal

Phase 0, complete with this prototype: the core protocols proven executable.
Capability table with generation-based revocation, multi-consumer zero-copy
seqlock streaming, supervised driver crash recovery, and verify-or-rollback A/B
updates, all running as real processes over real shared memory, built from
Assembly, C, C++, and Rust by one Makefile.

Phase 1, freestanding kernel: retarget the Rust core to `#![no_std]` on
x86_64-unknown-none. Limine or a UEFI stub boots it; bring-up order is serial
logging, physical frame allocator, page tables, GDT/IDT, then a round-robin
scheduler. The capability table transfers verbatim. Exit criterion: the kernel
schedules two in-kernel threads and prints over serial from QEMU.

Phase 2, user mode and real IPC: syscall entry (SYSCALL/SYSRET), ELF loading,
and shared-memory establishment as a kernel service — the mmap of the prototype
becomes page-table manipulation, and revocation gains its enforcement half
(unmap, not just observe). Port the C driver and C++ app binaries in. Exit
criterion: this repo's demo scenario runs unmodified in QEMU on our kernel.

Phase 3, real hardware I/O: user-space USB (xHCI) and a UVC camera driver so the
synthetic frames become genuine webcam frames through the same region format;
IOMMU domains per driver, which is the precondition for shipping unrestricted
MMIO to anyone. Virtio drivers first, since QEMU is the daily target.

Phase 4, the face: a GPU-accelerated compositor speaking the region protocol,
the infinite canvas with fluid window physics, the Accelerator HUD, and the
gesture service swapping its stand-in hash for a real landmark model on the NPU.
Time-Stream indexing lands here, feeding the local vector store from file events.

Phase 5, ecosystem: WASM runtime as the first-class app target, the Linux
micro-VM compatibility layer for day-one software breadth, Nexus Marketplace
intake (static analysis plus style verification), and signed decentralized
sideloading. Formal verification of the capability and IPC state machines gates
this phase — before third-party code runs, the mediation layer's proofs exist.

Sequencing rationale: everything depends on the capability and IPC layer being
right, which is why Phase 0 built and tested exactly that layer first, and why
its protocols are designed to survive the trip to metal without revision.
