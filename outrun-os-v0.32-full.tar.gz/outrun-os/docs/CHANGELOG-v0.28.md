# Outrun OS v0.28 — live application surfaces (Time-Stream integration)

The canvas panels stop being mock-ups. Each one now renders real state pulled
from the kernel subsystems built earlier in this project, so the UI is a live
view of the machine rather than a rendering demo.

## The surfaces
- **TIME-STREAM** — the actual Time-Stream event log: every event's tick, origin
  and text, newest first, colour-coded by kind (FILE mint / COMM magenta / SYS
  amber). These are the same events emitted by vfs_write_file and friends, e.g.
  "t=48 COMM Sarah: shared the Q3 revenue chart deck".
- **COMM-DECK** — filtered to communication events only, the Unified Stream in
  miniature.
- **SYS.TELEMETRY** — live kernel counters: uptime ticks, background
  descriptor-sweep passes / entries audited / violations found (red if non-zero),
  PS/2 mouse packet count, registered capability-gated devices, and whether DMA
  remapping is active.
- **TIME-NODE** — Time-Stream depth (events + how many the background vectorizer
  has indexed), CAS blocks in use, and live canvas camera state.
- **VIDEO-EDITOR** — framebuffer geometry, live cursor position, wheel presence.

## How it is wired
- ts_count/ts_who/ts_text/ts_tick_of/ts_type_of/ts_indexed accessors expose the
  Time-Stream to the compositor (which is compiled before it) without moving
  code or duplicating state — the panels read the live arrays, they do not copy.
- surface_render(i, x, y, w, h) replaces the demo meters; it is zoom-aware and
  computes how many rows/columns actually fit, so surfaces degrade gracefully as
  a panel shrinks and vanish entirely below the LOD threshold.
- draw_clip() keeps text inside the panel at any zoom; draw_kv()/draw_u64_at()
  render integers without any libc.

## Verified
Boot renders the canvas with all five surfaces live; the Time-Stream panel shows
the same events the `stream` command queries ("the Q3 chart Sarah sent" -> Sarah's
COMM event, score 4). Screenshot: docs/live-surfaces.png.
    [canvas ] 300 frames | camera world (-30,0) zoom 88% | focus 'TIME-STREAM'

## Honest scope
- Surfaces are read-only views: you cannot yet act on an event (click a
  Time-Stream entry to restore that workspace state, as the blueprint describes).
- Rendering is immediate-mode and re-reads the arrays every frame; there is no
  damage tracking or per-surface caching.
- Panels are still kernel-drawn; they are not ring-3 application surfaces owned
  by separate processes.

## Status
All prior suites remain green: 19/19 validation, 21/21 invariants, 10/10 stress,
8/8 fuzz, 2/2 iommu, 11/11 capdma, 6/6 cursor, 8/8 kinetic, ring-3 userspace
driver TX completed, plus CAS, DHCP, ring-3 demos, canvas and shell. Zero exceptions.
