# Outrun OS v0.9 — Phase 2: preemptive scheduler + multiple outstanding I/O

The kernel now runs multiple threads with a real PCB, time-slices them off the
PIT, and keeps many disk requests in flight at once — the bottom half wakes the
specific thread that owns each completed tag.

## Scheduler (boot/switch.asm + kernel)
- Per-thread PCB: saved RSP, address space (cr3), state, wait tag, entry/arg,
  and a dedicated 16 KiB kernel stack. (Kernel threads share kernel_cr3; the
  cr3 field is the hook for ring-3 threads later.)
- switch_context (assembly): saves callee-saved regs + RFLAGS, swaps stacks, so
  the interrupt-enable state travels with each thread.
- Round-robin pick with an idle thread (halts when nothing else is runnable).
- Cooperative sched_yield() for voluntary switches; PIT-driven sched_preempt()
  for time slicing, gated by a preempt-disable count so critical sections and
  the ring-3 excursion are never interrupted mid-flight.

## Multiple outstanding I/O (virtio-blk reworked)
- The single-request path is replaced with a slot table (one slot per in-flight
  request, 3 descriptors each — up to 21 concurrent on a 64-entry queue).
- vblk_submit() publishes a request and returns a tag WITHOUT blocking;
  vblk_wait(tag) parks the calling THREAD (not the CPU) until its tag completes.
- The bottom half drains ALL completed used-ring entries per interrupt and wakes
  each owning thread by TID.

## Proof (docs/scheduler-boot.log)
- `submitted 8 reads without blocking; in-flight now 8` ->
  `all 8 done; PEAK concurrent in-flight tags = 8` (deterministic on BIOS + UEFI).
- 4 worker threads each run 4 write+read cycles concurrently, all verified;
  completions arrive out of submission order and wakes route to the right TID.
- Preemption proof: a CPU-bound thread that never yields still advances ~40M
  increments while main also holds the CPU in its own non-yielding loop — only
  the timer could interleave them. (0 would mean no time-slicing.)
- CAS persistence/dedup and the polyglot C/C++/Rust/asm image are unchanged;
  the ring-3 SYSCALL passthrough path still works.

## Scope / next
- Cooperative + on-demand preemption (enabled around the concurrency demo).
  Ring-3 threads and full always-on preemption with per-CPU run queues come with
  the VFS/user-thread work. Single virtqueue; 512-byte requests.
