# Outrun OS v0.27 — kinetic camera physics (momentum + easing)

The canvas stops teleporting. Panning carries momentum, zoom eases toward a
target, and commands glide instead of snapping — the "fluid, physics-based"
half of the blueprint's interface promise. All fixed-point: no FPU anywhere.

## Momentum
- The camera has velocity and per-frame friction (0.88). Keyboard pan is now an
  IMPULSE (scaled by 1/zoom so it feels constant at any scale), not a jump.
- Fling: dragging empty canvas tracks a smoothed drag speed; on release the
  camera keeps gliding and decays to rest. Velocity snaps to exactly zero below
  a threshold, so the camera always comes to a true stop (no endless creep).

## Eased zoom, anchored every frame
- Wheel/keyboard zoom sets a TARGET; the camera eases toward it (0.25/frame).
- The hard part: the world point under the anchor is re-pinned on EVERY frame of
  the transition — the world point is sampled before each zoom step and the
  camera is re-derived after it. Naive implementations only anchor at the
  endpoints, which makes the view visibly slide mid-animation.

## Glide instead of teleport
- `focus`, `zoom fit`, `center canvas` and TAB now set a camera/zoom target and
  ease into it (0.22/frame), converging exactly and then latching.
- A manual zoom or pan impulse cancels an in-flight glide (input always wins).

## `kinetic` command — 8/8 invariants
- A flick imparts momentum (camera keeps moving after input stops).
- Friction brings the camera to a COMPLETE rest — settled in 48 frames over a
  199-world-unit glide.
- Glide distance is bounded (no runaway).
- Eased zoom converges to its target.
- **The anchor stays pinned on EVERY frame of the eased zoom: worst
  mid-transition drift 0 world units across 4 large zooms at different anchors.**
- Commanded glide converges exactly on its target (25 frames to focus).
- Eased zoom never overshoots.
- Zoom stays clamped to 12.5%..400% under 40 repeated impulses in each direction.

## Honest scope
- Zoom easing is linear in linear space rather than in log space; it reads well
  at these ratios, but log-space easing would be more perceptually uniform.
- Friction/easing constants are hand-tuned, not derived from a frame clock, so
  the feel is tied to the ~50 fps loop rather than being frame-rate independent.
- Windows keep their existing spring/collision physics; momentum applies to the
  camera only.

## Status
All prior suites remain green: 19/19 validation, 21/21 invariants, 10/10 stress,
8/8 fuzz, 2/2 iommu, 11/11 capdma, 6/6 cursor, 8/8 kinetic, ring-3 userspace
driver TX completed, plus CAS, DHCP, compositor, ring-3 demos, canvas, shell.
Zero exceptions.
