# Outrun OS v0.8 — interrupt-driven virtio-blk (async backbone)

The block driver no longer spins on the used ring. Disk I/O now completes on a
real hardware interrupt, with a clean top/bottom-half split and a sleeping
waiter — the asynchronous backbone the higher layers will build on.

## Interrupt path
- Parses the virtio ISR-status capability (cfg_type 3) and maps that register.
- Reads the PCI Interrupt Line (config 0x3C): the device is on legacy INTx,
  IRQ 11 -> PIC-remapped vector 43. (No MSI-X enabled, so the device uses INTx.)
- New PIC unmask helper + a per-IRQ handler table; isr_dispatch now routes
  device IRQs (vectors 34..47) to the registered handler.

## Top / bottom-half split
- TOP HALF (interrupt context, minimal): read the ISR-status register — which
  de-asserts the INTx line — and, if it's a queue interrupt, flag the bottom
  half. Then EOI. Nothing heavy runs at interrupt time.
- BOTTOM HALF (thread context, IRQs on): drain the used ring, capture the
  request status, and mark the request complete (wake the waiter).

## Sleeping waiter (poll retired)
- virtio_blk_request() arms the completion flags, publishes on the avail ring,
  kicks the notify register, then BLOCKS BY SLEEPING: `sti; hlt` halts the CPU
  until an interrupt arrives. The cli/check/sti-hlt idiom is race-free (an IRQ
  between the check and the halt is not lost). The 100 Hz timer provides a
  bounded fallback so a mis-routed INTx can never hang the kernel.

## Proof (docs/interrupt-driven-boot.log)
- `interrupt-driven: INTx on IRQ 11 (vector 43), ISR reg mapped`
- After the CAS format/put/get workload: `I/O completions delivered by
  INTERRUPT: 40 (timer-fallback: 0)` — every completion came from a hardware
  IRQ; the fallback never fired. On a subsequent (mount-only) boot: 17, again
  all by interrupt. Verified under both SeaBIOS and OVMF/UEFI, and CAS
  persistence/dedup across boots is unchanged.

## Why this matters
- Execution no longer locks up waiting on storage — the basis for async I/O.
- The top/bottom-half split is the hook a real scheduler will use to wake
  sleeping threads on hardware events.
- The block layer is now efficient enough to sit under a scalable index or an
  immutable file namespace without a polling bottleneck.
