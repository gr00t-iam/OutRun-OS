; =============================================================================
; OUTRUN OS — x86_64 HOT-PATH PRIMITIVES (ring_fastpath.asm)
; =============================================================================
; These are the instructions that execute millions of times per second inside
; every consumer's poll loop. They are deliberately hand-written: no function
; prologue, no stack traffic, no branches on the happy path.
;
; Offsets mirror outrun_camera_region in include/outrun_abi.h:
;     cap_gen[8]      @ +0     (8 * u64)
;     latest          @ +64
;     frames_written  @ +72
;
; SysV AMD64 calling convention: args in RDI, RSI, RDX; return in RAX.
; Aligned 8-byte loads on x86_64 are single-copy atomic, so plain MOVs give
; us acquire-ish semantics for these monotonically increasing counters.
; =============================================================================

global outrun_fast_latest
global outrun_cap_check
global outrun_cpu_relax

section .text

; ----------------------------------------------------------------------------
; uint64_t outrun_fast_latest(const void *region_base /* rdi */)
;   One MOV. This is the entire per-poll kernel-free cost of "unrestricted
;   hardware access" after a capability grant.
; ----------------------------------------------------------------------------
outrun_fast_latest:
    mov     rax, [rdi + 64]        ; region->latest
    ret

; ----------------------------------------------------------------------------
; uint64_t outrun_cap_check(const void *region_base /* rdi */,
;                           uint64_t    cap_index   /* rsi */,
;                           uint64_t    expected    /* rdx */)
;   Returns 0 while the mapping is live, 1 the instant the kernel bumps the
;   holder's generation slot. Revocation without interrupting the process.
; ----------------------------------------------------------------------------
outrun_cap_check:
    mov     rax, [rdi + rsi*8]     ; region->cap_gen[cap_index]
    cmp     rax, rdx
    jne     .revoked
    xor     eax, eax               ; 0 = live
    ret
.revoked:
    mov     eax, 1                 ; 1 = revoked
    ret

; ----------------------------------------------------------------------------
; void outrun_cpu_relax(void)
;   PAUSE tells the core we are spin-waiting: saves power, unblocks the
;   sibling hyperthread, and avoids the memory-order machine clear on exit.
; ----------------------------------------------------------------------------
outrun_cpu_relax:
    pause
    ret
